export type AssetId =
  | 'sampul'
  | 'latar_pertemuan_1'
  | 'latar_pertemuan_2'
  | 'latar_pertemuan_3'
  | 'latar_pertemuan_4'
  | 'objek_matahari'
  | 'objek_planet'
  | 'objek_rotasi'
  | 'objek_revolusi'
  | 'objek_siang_dan_malam'
  | 'objek_simulasi_rotasi_dan_revo'
  | 'lencana_bintang'
  | 'lencana_juara'
  | 'lencana_pintar';

export interface AssetManifestItem {
  id: AssetId;
  file: string;
  kind: 'scene' | 'background' | 'object' | 'badge';
  purpose: string;
  used_on: string;
  must_depict: string[];
  aspect_ratio: '16:9' | '1:1';
  background: 'full_scene' | 'transparent';
  alt_text: string;
}

export type SteamTag = 'Sains' | 'Teknologi' | 'Rekayasa' | 'Seni' | 'Matematika';

export type ScreenKind =
  | 'dialog'
  | 'explore_map'
  | 'order_planets'
  | 'compare_sizes'
  | 'simulation_rotation'
  | 'simulation_revolution'
  | 'practice_checklist'
  | 'quiz'
  | 'reflection'
  | 'celebration';

export interface DialogScreen {
  kind: 'dialog';
  id: string;
  title: string;
  text: string;
  assetId: AssetId;
  animation?: 'float' | 'bounce' | 'sway' | 'fade';
}

export interface ExploreMapScreen {
  kind: 'explore_map';
  id: string;
  title: string;
  text: string;
}

export interface OrderPlanetsScreen {
  kind: 'order_planets';
  id: string;
  title: string;
  text: string;
}

export interface CompareSizesScreen {
  kind: 'compare_sizes';
  id: string;
  title: string;
  text: string;
}

export interface SimulationRotationScreen {
  kind: 'simulation_rotation';
  id: string;
  title: string;
  text: string;
}

export interface SimulationRevolutionScreen {
  kind: 'simulation_revolution';
  id: string;
  title: string;
  text: string;
}

export interface PracticeChecklistScreen {
  kind: 'practice_checklist';
  id: string;
  title: string;
  text: string;
  assetId: AssetId;
  mediaNote: string;
  steps: string[];
  observationPrompt: string;
  observationOptions: string[];
}

export interface QuizOption {
  id: string;
  label: string;
  assetId?: AssetId;
}

export interface QuizQuestion {
  id: string;
  level: 1 | 2 | 3 | 4;
  title: string;
  question: string;
  assetId: AssetId;
  options: QuizOption[];
  correctOptionId: string;
  hints: [string, string, string];
  correctFeedback: string;
  wrongFeedback: string;
  reasonPrompt?: string;
  reasonOptions?: QuizOption[];
  correctReasonId?: string;
  reasonFeedback?: string;
}

export interface QuizScreen {
  kind: 'quiz';
  id: string;
  questionData: QuizQuestion;
}

export interface ReflectionScreen {
  kind: 'reflection';
  id: string;
  meetingNumber: 1 | 2 | 3 | 4;
  title: string;
  text: string;
  assetId: AssetId;
  learnedOptions: string[];
}

export interface CelebrationScreen {
  kind: 'celebration';
  id: string;
  title: string;
  text: string;
  badgeId: AssetId;
  badgeTitle: string;
}

export type MissionScreen =
  | DialogScreen
  | ExploreMapScreen
  | OrderPlanetsScreen
  | CompareSizesScreen
  | SimulationRotationScreen
  | SimulationRevolutionScreen
  | PracticeChecklistScreen
  | QuizScreen
  | ReflectionScreen
  | CelebrationScreen;

export interface Mission {
  id: string;
  meetingId: number;
  orderInMeeting: number;
  title: string;
  shortDesc: string;
  objective: string;
  steamTags: SteamTag[];
  backgroundAssetId: AssetId;
  coverAssetId: AssetId;
  screens: MissionScreen[];
}

export interface Meeting {
  id: 1 | 2 | 3 | 4;
  title: string;
  subtitle: string;
  objective: string;
  backgroundAssetId: AssetId;
  missions: Mission[];
}

export interface QuizAttemptRecord {
  questionId: string;
  missionId: string;
  firstTryCorrect: boolean;
  attempts: number;
  selectedReason?: string;
}

export interface ReflectionRecord {
  meetingNumber: number;
  mood: 'senang' | 'paham' | 'bingung';
  learned: string;
  updatedAt: string;
}

export interface ProgressState {
  completedMissionIds: string[];
  starsByMission: Record<string, number>;
  unlockedBadges: AssetId[];
  quizRecords: Record<string, QuizAttemptRecord>;
  finalQuizCompleted: boolean;
  finalQuizCorrectFirstTry: number;
  finalQuizTotal: number;
  reflections: Record<number, ReflectionRecord>;
  practiceObservations: Record<string, string>;
  storageEnabled: boolean;
}

export type AppPage =
  | 'welcome'
  | 'map'
  | 'mission'
  | 'glossary'
  | 'facts'
  | 'final_quiz'
  | 'badges'
  | 'parent_teacher'
  | 'asset_gallery';
