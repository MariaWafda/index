import React, { useState } from 'react';
import { GLOSSARY_ITEMS } from '../data/solarSystem';
import { AssetImage } from '../components/AssetImage';
import { TopBar } from '../components/TopBar';
import { BottomNav } from '../components/BottomNav';

interface GlossaryPageProps {
  isSpeaking: boolean;
  isMuted: boolean;
  onToggleSpeak: (text: string) => void;
  onToggleMute: () => void;
  onBackToMap: () => void;
}

export const GlossaryPage: React.FC<GlossaryPageProps> = ({
  isSpeaking,
  isMuted,
  onToggleSpeak,
  onToggleMute,
  onBackToMap,
}) => {
  const [index, setIndex] = useState(0);
  const item = GLOSSARY_ITEMS[index] || GLOSSARY_ITEMS[0];

  const speakText = `${item.term}. ${item.meaning} ${item.example}`;

  return (
    <div className="safe-viewport w-full overflow-hidden bg-gradient-to-b from-sky-100 via-sky-50 to-amber-50 flex flex-col justify-between">
      <TopBar
        currentStep={index}
        totalSteps={GLOSSARY_ITEMS.length}
        isSpeaking={isSpeaking}
        onToggleSpeak={() => onToggleSpeak(speakText)}
        isMuted={isMuted}
        onToggleMute={onToggleMute}
        onBackToMap={onBackToMap}
      />

      <main className="flex-1 min-h-0 max-w-5xl w-full mx-auto px-4 py-3 flex flex-col md:grid md:grid-cols-12 items-center justify-center gap-4 overflow-hidden">
        <div className="md:col-span-6 w-full flex-1 md:flex-none min-h-0 flex items-center justify-center max-h-[36vh] md:max-h-[58vh]">
          <AssetImage
            assetId={item.assetId}
            animation="float"
            labelBadge={item.term}
            className="w-full h-full max-h-full"
          />
        </div>

        <div className="md:col-span-6 w-full flex flex-col items-center md:items-start text-center md:text-left gap-2 shrink-0">
          <span className="text-sm sm:text-base font-extrabold text-[#0284c7]">
            Glosarium Bergambar · Kata {index + 1} dari {GLOSSARY_ITEMS.length}
          </span>
          <h1 className="font-extrabold text-[clamp(26px,4.5vw,44px)] text-slate-950 leading-tight">
            {item.term}
          </h1>
          <p className="font-bold text-[clamp(19px,3.4vw,28px)] text-slate-800 leading-snug">
            {item.meaning}
          </p>
          <div className="mt-1 px-4 py-2 rounded-2xl bg-amber-100 border-2 border-amber-400 text-amber-950 font-bold text-[clamp(16px,2.8vw,22px)]">
            Contoh: {item.example}
          </div>
        </div>
      </main>

      <BottomNav
        onBack={() => {
          if (index === 0) onBackToMap();
          else setIndex((i) => i - 1);
        }}
        onNext={() => {
          if (index === GLOSSARY_ITEMS.length - 1) onBackToMap();
          else setIndex((i) => i + 1);
        }}
        backLabel={index === 0 ? 'Peta' : 'Kembali'}
        nextLabel={index === GLOSSARY_ITEMS.length - 1 ? 'Selesai' : 'Lanjut'}
      />
    </div>
  );
};
