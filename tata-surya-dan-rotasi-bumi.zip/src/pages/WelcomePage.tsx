import React from 'react';
import {
  Rocket,
  BookOpen,
  Sparkles,
  Award,
  Users,
  Speech,
  Square,
  EyeOff,
  Eye,
} from 'lucide-react';
import { AssetImage } from '../components/AssetImage';
import { AppPage } from '../types/app';
import { playTapSound } from '../utils/audio';

interface WelcomePageProps {
  onStart: () => void;
  onNavigate: (page: AppPage) => void;
  isSpeaking: boolean;
  onToggleSpeak: (text: string) => void;
  reduceMotion: boolean;
  onToggleReduceMotion: () => void;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({
  onStart,
  onNavigate,
  isSpeaking,
  onToggleSpeak,
  reduceMotion,
  onToggleReduceMotion,
}) => {
  const welcomeSpeech =
    'Tata Surya dan Rotasi Bumi. Bertumbuh Bersama Kita Bisa. Ayo mulai petualangan Penjelajah Antariksa Si Bintang.';

  return (
    <div className="safe-viewport w-full overflow-hidden bg-gradient-to-b from-sky-100 via-sky-50 to-amber-50 flex flex-col justify-between">
      {/* Compact Top Utility Row */}
      <header className="w-full shrink-0 px-3 pt-2.5 pb-1 flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => {
            playTapSound();
            onToggleReduceMotion();
          }}
          className="min-h-[44px] px-3 rounded-2xl bg-white/90 border-2 border-sky-200 text-slate-800 font-bold text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer"
        >
          {reduceMotion ? (
            <EyeOff className="w-4 h-4 shrink-0" aria-hidden="true" />
          ) : (
            <Eye className="w-4 h-4 shrink-0" aria-hidden="true" />
          )}
          <span className="whitespace-nowrap">
            {reduceMotion ? 'Animasi Mati' : 'Animasi Nyala'}
          </span>
        </button>

        <button
          type="button"
          onClick={() => {
            playTapSound();
            onToggleSpeak(welcomeSpeech);
          }}
          className={`min-h-[44px] px-3.5 rounded-2xl border-2 font-extrabold text-sm sm:text-base flex items-center gap-1.5 cursor-pointer ${
            isSpeaking
              ? 'bg-rose-100 border-rose-400 text-rose-950'
              : 'bg-[#ffc83d] border-amber-500 text-slate-950'
          }`}
        >
          {isSpeaking ? (
            <>
              <Square className="w-4 h-4 fill-current" aria-hidden="true" />
              <span>Henti</span>
            </>
          ) : (
            <>
              <Speech className="w-5 h-5" aria-hidden="true" />
              <span>Baca</span>
            </>
          )}
        </button>
      </header>

      {/* Main Centered Hero: Portrait stacked, Landscape 2-column */}
      <main className="flex-1 min-h-0 px-4 py-2 flex flex-col md:grid md:grid-cols-12 items-center justify-center gap-3 md:gap-6 max-w-6xl w-full mx-auto overflow-hidden">
        <div className="md:col-span-6 w-full flex-1 md:flex-none min-h-0 flex items-center justify-center max-h-[34vh] md:max-h-[60vh]">
          <AssetImage
            assetId="sampul"
            animation="float"
            labelBadge="Penjelajah Antariksa Si Bintang"
            className="w-full h-full max-h-full rounded-3xl"
          />
        </div>

        <div className="md:col-span-6 w-full flex flex-col items-center md:items-start text-center md:text-left gap-2 shrink-0">
          <p className="text-sm sm:text-base font-extrabold text-[#0284c7]">
            Penjelajah Antariksa Si Bintang · IPAS Kelas 6
          </p>
          <h1 className="font-extrabold text-[clamp(28px,5.2vw,52px)] text-slate-950 leading-[1.1] text-balance">
            Tata Surya dan Rotasi Bumi
          </h1>
          <p className="font-bold text-[clamp(18px,3.2vw,28px)] text-slate-800 leading-snug">
            Bertumbuh Bersama Kita Bisa
          </p>

          <button
            type="button"
            onClick={() => {
              playTapSound();
              onStart();
            }}
            className="mt-1 w-full sm:w-auto min-w-[240px] min-h-[58px] px-6 py-3 rounded-3xl bg-[#5bcb7a] hover:bg-emerald-500 border-4 border-emerald-600 text-slate-950 font-extrabold text-[clamp(22px,4vw,28px)] flex items-center justify-center gap-2.5 shadow-md transition-transform active:scale-95 cursor-pointer"
          >
            <Rocket className="w-7 h-7 shrink-0" aria-hidden="true" />
            <span>Mulai Jelajah</span>
          </button>
        </div>
      </main>

      {/* Bottom Quick Feature Bar */}
      <nav
        aria-label="Menu Tambahan"
        className="w-full shrink-0 bg-white/90 border-t-2 border-sky-200 px-3 py-2 grid grid-cols-4 gap-2 max-w-4xl mx-auto rounded-t-3xl"
      >
        {[
          { page: 'glossary' as const, label: 'Glosarium', Icon: BookOpen },
          { page: 'facts' as const, label: 'Fakta Unik', Icon: Sparkles },
          { page: 'badges' as const, label: 'Hadiah', Icon: Award },
          { page: 'parent_teacher' as const, label: 'Guru / Ortu', Icon: Users },
        ].map(({ page, label, Icon }) => (
          <button
            key={page}
            type="button"
            onClick={() => {
              playTapSound();
              onNavigate(page);
            }}
            className="min-h-[48px] px-1.5 py-1 rounded-2xl bg-sky-50 hover:bg-sky-100 border-2 border-sky-200 text-slate-900 font-bold text-xs sm:text-sm md:text-base flex flex-col sm:flex-row items-center justify-center gap-1 cursor-pointer transition-transform active:scale-95"
          >
            <Icon className="w-5 h-5 text-[#0284c7] shrink-0" aria-hidden="true" />
            <span className="truncate max-w-full">{label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};
