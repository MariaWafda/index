import React, { useEffect, useState } from 'react';
import { ArrowLeft, CheckCircle2, AlertCircle } from 'lucide-react';
import { ASSET_MANIFEST } from '../data/assets';
import { AssetManifestItem } from '../types/app';

interface AssetGalleryPageProps {
  onBackToApp: () => void;
}

type FileStatus = 'memeriksa' | 'ada' | 'belum_ada';

export const AssetGalleryPage: React.FC<AssetGalleryPageProps> = ({
  onBackToApp,
}) => {
  const [statuses, setStatuses] = useState<Record<string, FileStatus>>({});

  useEffect(() => {
    let active = true;
    ASSET_MANIFEST.forEach((item) => {
      const img = new Image();
      img.onload = () => {
        if (!active) return;
        setStatuses((prev) => ({ ...prev, [item.id]: 'ada' }));
      };
      img.onerror = () => {
        if (!active) return;
        setStatuses((prev) => ({ ...prev, [item.id]: 'belum_ada' }));
      };
      img.src = item.file;
    });
    return () => {
      active = false;
    };
  }, []);

  const readyCount = Object.values(statuses).filter((s) => s === 'ada').length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 p-4 sm:p-6 overflow-y-auto">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b-2 border-slate-200">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-950">
              Galeri Pemeriksa Aset Guru
            </h1>
            <p className="text-sm sm:text-base font-semibold text-slate-700 mt-1">
              Letakkan berkas PNG di folder <code className="bg-slate-200 px-1.5 py-0.5 rounded">public/assets/</code> sesuai nama di bawah ini. Status tersedia: <strong className="tabular-nums">{readyCount} dari {ASSET_MANIFEST.length}</strong> berkas.
            </p>
          </div>
          <button
            type="button"
            onClick={onBackToApp}
            className="min-h-[48px] px-4 py-2 rounded-2xl bg-[#29b1f5] hover:bg-sky-400 border-2 border-sky-700 text-slate-950 font-extrabold flex items-center gap-2 cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" aria-hidden="true" />
            <span>Kembali ke Aplikasi</span>
          </button>
        </div>

        <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {ASSET_MANIFEST.map((item: AssetManifestItem) => {
            const st = statuses[item.id] || 'memeriksa';
            return (
              <div
                key={item.id}
                className="bg-white border-2 border-slate-200 rounded-3xl p-4 flex flex-col justify-between gap-3 shadow-sm"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-extrabold text-slate-600 truncate">
                    {item.id}
                  </span>
                  {st === 'ada' ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-100 text-emerald-900 text-xs font-extrabold">
                      <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                      Ada
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-100 text-amber-950 text-xs font-extrabold">
                      <AlertCircle className="w-4 h-4" aria-hidden="true" />
                      {st === 'memeriksa' ? 'Memeriksa...' : 'Belum ada'}
                    </span>
                  )}
                </div>

                <div className="h-36 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center overflow-hidden p-2">
                  {st === 'ada' ? (
                    <img
                      src={item.file}
                      alt={item.alt_text}
                      className="max-h-full max-w-full object-contain"
                    />
                  ) : (
                    <div className="w-full h-full rounded-xl bg-sky-100 border-2 border-dashed border-sky-300 flex flex-col items-center justify-center p-2 text-center">
                      <span className="font-bold text-sm text-sky-950">
                        {item.alt_text}
                      </span>
                      <span className="text-xs text-sky-800 mt-1 break-all">
                        {item.file}
                      </span>
                    </div>
                  )}
                </div>

                <div className="text-xs sm:text-sm space-y-1 text-slate-700">
                  <div>
                    <strong>Berkas:</strong>{' '}
                    <code className="bg-slate-100 px-1 rounded break-all">{item.file}</code>
                  </div>
                  <div>
                    <strong>Dipakai di:</strong> {item.used_on}
                  </div>
                  <div>
                    <strong>Harus menampilkan:</strong> {item.must_depict.join(', ')}
                  </div>
                  <div>
                    <strong>Rasio:</strong> {item.aspect_ratio} · {item.background}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
