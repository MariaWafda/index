import React, { useEffect, useState } from 'react';
import { Star } from 'lucide-react';
import { AssetImage } from '../components/AssetImage';
import { BottomNav } from '../components/BottomNav';
import { TopBar } from '../components/TopBar';
import { CompareSizesScreen, Mission, MissionScreen, ProgressState } from '../types/app';
import { preloadAsset } from '../data/assets';
import { SolarMapView } from '../components/interactions/SolarMapView';
import { PlanetOrderView } from '../components/interactions/PlanetOrderView';
import { PlanetCompareView } from '../components/interactions/PlanetCompareView';
import { SimulationRotationView } from '../components/interactions/SimulationRotationView';
import { SimulationRevolutionView } from '../components/interactions/SimulationRevolutionView';
import { PracticeChecklistView } from '../components/interactions/PracticeChecklistView';
import { QuizQuestionView } from '../components/interactions/QuizQuestionView';
import { ReflectionView } from '../components/interactions/ReflectionView';
import { playCelebrationSound } from '../utils/audio';

interface MissionRunnerPageProps {
  mission: Mission;
  progress: ProgressState;
  reduceMotion: boolean;
  isSpeaking: boolean;
  isMuted: boolean;
  onToggleSpeak: (text: string) => void;
  onStopSpeak: () => void;
  onToggleMute: () => void;
  onExitToMap: () => void;
  onRecordQuizAnswer: (
    missionId: string,
    questionId: string,
    firstTryCorrect: boolean,
    attempts: number,
    selectedReason?: string
  ) => void;
  onSavePracticeObservation: (screenId: string, observation: string) => void;
  onSaveReflection: (
    meetingNumber: 1 | 2 | 3 | 4,
    mood: 'senang' | 'paham' | 'bingung',
    learned: string
  ) => void;
  onCompleteMission: (mission: Mission, badgeId: Mission['coverAssetId']) => void;
}

function getScreenSpeakText(screen: MissionScreen): string {
  switch (screen.kind) {
    case 'dialog':
      return `${screen.title}. ${screen.text}`;
    case 'explore_map':
    case 'order_planets':
    case 'compare_sizes':
    case 'simulation_rotation':
    case 'simulation_revolution':
      return `${screen.title}. ${screen.text}`;
    case 'practice_checklist':
      return `${screen.title}. ${screen.text} ${screen.steps.join('. ')}`;
    case 'quiz':
      return `${screen.questionData.title}. ${screen.questionData.question}`;
    case 'reflection':
      return `${screen.title}. ${screen.text}`;
    case 'celebration':
      return `${screen.title}. ${screen.text}`;
  }
}

export const MissionRunnerPage: React.FC<MissionRunnerPageProps> = ({
  mission,
  progress,
  reduceMotion,
  isSpeaking,
  isMuted,
  onToggleSpeak,
  onStopSpeak,
  onToggleMute,
  onExitToMap,
  onRecordQuizAnswer,
  onSavePracticeObservation,
  onSaveReflection,
  onCompleteMission,
}) => {
  const [stepIndex, setStepIndex] = useState<number>(0);
  const [completedQuizSteps, setCompletedQuizSteps] = useState<Record<string, boolean>>({});
  const [completedOrderSteps, setCompletedOrderSteps] = useState<Record<string, boolean>>({});

  const screens = mission.screens;
  const currentScreen = screens[stepIndex] || screens[0];
  const isLastStep = stepIndex === screens.length - 1;

  // Reset when mission changes
  useEffect(() => {
    setStepIndex(0);
    setCompletedQuizSteps({});
    setCompletedOrderSteps({});
  }, [mission.id]);

  // Preload next screen asset & play celebration sound when reaching celebration
  useEffect(() => {
    onStopSpeak();
    const nextScreen = screens[stepIndex + 1];
    if (nextScreen) {
      if ('assetId' in nextScreen) {
        preloadAsset(nextScreen.assetId);
      } else if (nextScreen.kind === 'quiz') {
        preloadAsset(nextScreen.questionData.assetId);
      } else if (nextScreen.kind === 'celebration') {
        preloadAsset(nextScreen.badgeId);
      }
    }

    if (currentScreen.kind === 'celebration') {
      playCelebrationSound();
      onCompleteMission(mission, currentScreen.badgeId);
    }
  }, [stepIndex, mission.id]);

  // Determine if Lanjut should wait for step completion
  let nextDisabled = false;
  if (currentScreen.kind === 'quiz') {
    nextDisabled = !completedQuizSteps[currentScreen.id];
  } else if (currentScreen.kind === 'order_planets') {
    nextDisabled = !completedOrderSteps[currentScreen.id];
  } else if (currentScreen.kind === 'reflection') {
    nextDisabled = !progress.reflections[currentScreen.meetingNumber]?.learned;
  }

  const handleBack = () => {
    if (stepIndex === 0) {
      onExitToMap();
    } else {
      setStepIndex((i) => Math.max(0, i - 1));
    }
  };

  const handleNext = () => {
    if (isLastStep) {
      onExitToMap();
    } else {
      setStepIndex((i) => Math.min(screens.length - 1, i + 1));
    }
  };

  return (
    <div className="safe-viewport w-full overflow-hidden bg-gradient-to-b from-sky-100 via-sky-50 to-amber-50 flex flex-col justify-between relative">
      {/* Subtle Meeting Background */}
      <div
        aria-hidden="true"
        className="absolute inset-0 opacity-15 pointer-events-none overflow-hidden flex items-center justify-center"
      >
        <AssetImage
          assetId={mission.backgroundAssetId}
          decorative
          className="w-full h-full object-cover"
        />
      </div>

      {/* Top Navigation */}
      <TopBar
        currentStep={stepIndex}
        totalSteps={screens.length}
        isSpeaking={isSpeaking}
        onToggleSpeak={() => onToggleSpeak(getScreenSpeakText(currentScreen))}
        isMuted={isMuted}
        onToggleMute={onToggleMute}
        onBackToMap={onExitToMap}
      />

      {/* Middle Stage (Always fits inside 100dvh with zero scroll) */}
      <main className="relative z-10 flex-1 min-h-0 w-full max-w-5xl mx-auto px-3 sm:px-6 py-2 sm:py-4 flex items-center justify-center overflow-hidden">
        {currentScreen.kind === 'dialog' && (
          <div className="w-full h-full flex flex-col md:grid md:grid-cols-12 items-center justify-center gap-3 md:gap-6 min-h-0 overflow-hidden">
            <div className="md:col-span-6 w-full flex-1 md:flex-none min-h-0 flex items-center justify-center max-h-[38vh] md:max-h-[60vh]">
              <AssetImage
                assetId={currentScreen.assetId}
                animation={currentScreen.animation || 'float'}
                className="w-full h-full max-h-full"
              />
            </div>

            <div className="md:col-span-6 w-full flex flex-col items-center md:items-start text-center md:text-left justify-center gap-2 shrink-0">
              <div className="text-sm sm:text-base font-extrabold text-[#0284c7]">
                {mission.title} · {mission.steamTags.join(' + ')}
              </div>
              <h2 className="font-extrabold text-[clamp(24px,4.5vw,42px)] text-slate-950 leading-[1.15] text-balance">
                {currentScreen.title}
              </h2>
              <p className="font-bold text-[clamp(20px,3.6vw,28px)] text-slate-800 leading-snug">
                {currentScreen.text}
              </p>
            </div>
          </div>
        )}

        {currentScreen.kind === 'explore_map' && (
          <SolarMapView
            title={currentScreen.title}
            text={currentScreen.text}
            onSpeakText={(txt) => onToggleSpeak(txt)}
          />
        )}

        {currentScreen.kind === 'order_planets' && (
          <PlanetOrderView
            title={currentScreen.title}
            text={currentScreen.text}
            onComplete={() =>
              setCompletedOrderSteps((prev) => ({ ...prev, [currentScreen.id]: true }))
            }
          />
        )}

        {currentScreen.kind === 'compare_sizes' && (
          <PlanetCompareView
            title={(currentScreen as CompareSizesScreen).title}
            text={(currentScreen as CompareSizesScreen).text}
          />
        )}

        {currentScreen.kind === 'simulation_rotation' && (
          <SimulationRotationView
            title={currentScreen.title}
            text={currentScreen.text}
            reduceMotion={reduceMotion}
          />
        )}

        {currentScreen.kind === 'simulation_revolution' && (
          <SimulationRevolutionView
            title={currentScreen.title}
            text={currentScreen.text}
            reduceMotion={reduceMotion}
          />
        )}

        {currentScreen.kind === 'practice_checklist' && (
          <PracticeChecklistView
            title={currentScreen.title}
            text={currentScreen.text}
            assetId={currentScreen.assetId}
            mediaNote={currentScreen.mediaNote}
            steps={currentScreen.steps}
            observationPrompt={currentScreen.observationPrompt}
            observationOptions={currentScreen.observationOptions}
            savedObservation={progress.practiceObservations[currentScreen.id]}
            onSaveObservation={(obs) =>
              onSavePracticeObservation(currentScreen.id, obs)
            }
          />
        )}

        {currentScreen.kind === 'quiz' && (
          <QuizQuestionView
            questionData={currentScreen.questionData}
            onSpeakText={(txt) => onToggleSpeak(txt)}
            onAnsweredCorrectly={(firstTry, attempts, reason) => {
              setCompletedQuizSteps((prev) => ({ ...prev, [currentScreen.id]: true }));
              onRecordQuizAnswer(
                mission.id,
                currentScreen.questionData.id,
                firstTry,
                attempts,
                reason
              );
            }}
          />
        )}

        {currentScreen.kind === 'reflection' && (
          <ReflectionView
            meetingNumber={currentScreen.meetingNumber}
            title={currentScreen.title}
            text={currentScreen.text}
            assetId={currentScreen.assetId}
            learnedOptions={currentScreen.learnedOptions}
            initialMood={progress.reflections[currentScreen.meetingNumber]?.mood}
            initialLearned={progress.reflections[currentScreen.meetingNumber]?.learned}
            onSaveReflection={(mood, learned) =>
              onSaveReflection(currentScreen.meetingNumber, mood, learned)
            }
          />
        )}

        {currentScreen.kind === 'celebration' && (
          <div className="w-full h-full flex flex-col md:grid md:grid-cols-12 items-center justify-center gap-4 min-h-0 overflow-hidden">
            <div className="md:col-span-5 flex-1 md:flex-none min-h-0 flex items-center justify-center max-h-[36vh] md:max-h-[55vh]">
              <AssetImage
                assetId={currentScreen.badgeId}
                animation="bounce"
                labelBadge={currentScreen.badgeTitle}
                className="w-full h-full max-h-full"
              />
            </div>

            <div className="md:col-span-7 flex flex-col items-center md:items-start text-center md:text-left gap-2 shrink-0">
              <div className="flex items-center gap-1.5 text-amber-700 font-extrabold text-base sm:text-xl">
                <Star className="w-6 h-6 fill-amber-400 text-amber-600" aria-hidden="true" />
                <Star className="w-6 h-6 fill-amber-400 text-amber-600" aria-hidden="true" />
                <Star className="w-6 h-6 fill-amber-400 text-amber-600" aria-hidden="true" />
                <span>+3 Bintang Penjelajah!</span>
              </div>
              <h2 className="font-extrabold text-[clamp(26px,4.5vw,44px)] text-slate-950 leading-tight">
                {currentScreen.title}
              </h2>
              <p className="font-bold text-[clamp(18px,3.2vw,28px)] text-slate-800 leading-snug">
                {currentScreen.text}
              </p>
              <div className="mt-1 px-4 py-2 rounded-2xl bg-emerald-100 border-2 border-emerald-500 text-emerald-950 font-extrabold text-base sm:text-xl">
                Hadiah Terbuka: {currentScreen.badgeTitle}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        onBack={handleBack}
        onNext={handleNext}
        backLabel={stepIndex === 0 ? 'Peta' : 'Kembali'}
        nextLabel={isLastStep ? 'Selesai' : 'Lanjut'}
        nextDisabled={nextDisabled}
      />
    </div>
  );
};
