import React, { useState } from 'react';
import {
  Star,
  Lock,
  Play,
  CheckCircle2,
  BookOpen,
  Sparkles,
  Award,
  Users,
  Home,
  Trophy,
} from 'lucide-react';
import { ALL_MISSIONS, MEETINGS } from '../data/curriculum';
import { AssetImage } from '../components/AssetImage';
import { AppPage, Mission, ProgressState } from '../types/app';
import { playTapSound } from '../utils/audio';

interface MissionMapPageProps {
  progress: ProgressState;
  teacherUnlockAll: boolean;
  onSelectMission: (mission: Mission) => void;
  onNavigate: (page: AppPage) => void;
  isSpeaking: boolean;
  onToggleSpeak: (text: string) => void;
}

export const MissionMapPage: React.FC<MissionMapPageProps> = ({
  progress,
  teacherUnlockAll,
  onSelectMission,
  onNavigate,
  isSpeaking,
  onToggleSpeak,
}) => {
  // Default to the meeting containing the next uncompleted mission
  const firstPending = ALL_MISSIONS.find(
    (m) => !progress.completedMissionIds.includes(m.id)
  );
  const [activeMeetingId, setActiveMeetingId] = useState<number>(
    firstPending?.meetingId || 1
  );

  const activeMeeting =
    MEETINGS.find((m) => m.id === activeMeetingId) || MEETINGS[0];

  const totalStars = Object.values(progress.starsByMission).reduce(
    (sum, s) => sum + s,
    0
  );
  const allCompleted = ALL_MISSIONS.every((m) =>
    progress.completedMissionIds.includes(m.id)
  );

  const isMissionUnlocked = (missionId: string): boolean => {
    if (teacherUnlockAll) return true;
    const idx = ALL_MISSIONS.findIndex((m) => m.id === missionId);
    if (idx <= 0) return true;
    const prevId = ALL_MISSIONS[idx - 1].id;
    return (
      progress.completedMissionIds.includes(missionId) ||
      progress.completedMissionIds.includes(prevId)
    );
  };

  return (
    <div className="safe-viewport w-full overflow-hidden bg-gradient-to-b from-sky-100 via-sky-50 to-emerald-50 flex flex-col justify-between">
      {/* Header */}
      <header className="w-full shrink-0 bg-white/95 border-b-2 border-sky-200 px-3 py-2 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <button
            type="button"
            onClick={() => {
              playTapSound();
              onNavigate('welcome');
            }}
            className="min-h-[44px] px-3 rounded-2xl bg-sky-100 hover:bg-sky-200 text-sky-950 font-bold text-sm sm:text-base flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <Home className="w-5 h-5 shrink-0" aria-hidden="true" />
            <span className="hidden sm:inline">Awal</span>
          </button>
          <h1 className="font-extrabold text-[clamp(18px,3.2vw,26px)] text-slate-950 truncate">
            Peta Perjalanan Misi
          </h1>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              playTapSound();
              onToggleSpeak(
                `${activeMeeting.title}. ${activeMeeting.subtitle}. Ketuk misi yang terbuka untuk memulai.`
              );
            }}
            className={`min-h-[44px] px-3 rounded-2xl border-2 font-extrabold text-sm sm:text-base cursor-pointer ${
              isSpeaking
                ? 'bg-rose-100 border-rose-400 text-rose-950'
                : 'bg-[#ffc83d] border-amber-500 text-slate-950'
            }`}
          >
            {isSpeaking ? 'Henti' : 'Baca'}
          </button>

          <div
            className="min-h-[44px] px-3 rounded-2xl bg-amber-100 border-2 border-amber-400 text-amber-950 font-extrabold text-sm sm:text-base flex items-center gap-1.5 tabular-nums"
            aria-label={`Jumlah bintang: ${totalStars}`}
          >
            <Star className="w-5 h-5 fill-amber-400 text-amber-600 shrink-0" aria-hidden="true" />
            <span>{totalStars}</span>
          </div>
        </div>
      </header>

      {/* Main Content: Meeting Selector + 4 Mission Cards */}
      <main className="flex-1 min-h-0 px-3 py-2 flex flex-col gap-2 max-w-5xl w-full mx-auto overflow-hidden">
        {/* 4 Meeting Tabs */}
        <div className="grid grid-cols-4 gap-1.5 sm:gap-2 shrink-0">
          {MEETINGS.map((meeting) => {
            const isActive = meeting.id === activeMeetingId;
            const doneInMeeting = meeting.missions.filter((m) =>
              progress.completedMissionIds.includes(m.id)
            ).length;
            return (
              <button
                key={meeting.id}
                type="button"
                onClick={() => {
                  playTapSound();
                  setActiveMeetingId(meeting.id);
                }}
                className={`min-h-[48px] px-2 py-1.5 rounded-2xl border-2 font-extrabold text-xs sm:text-base flex flex-col items-center justify-center transition-transform active:scale-95 cursor-pointer ${
                  isActive
                    ? 'bg-[#29b1f5] border-sky-700 text-slate-950 shadow-sm'
                    : 'bg-white border-sky-200 text-slate-800 hover:bg-sky-50'
                }`}
              >
                <span className="truncate max-w-full">Pertemuan {meeting.id}</span>
                <span className="text-[11px] sm:text-xs font-bold opacity-80 tabular-nums">
                  {doneInMeeting}/4 Misi
                </span>
              </button>
            );
          })}
        </div>

        {/* Meeting Banner with Background Asset */}
        <div className="bg-white border-2 border-sky-200 rounded-3xl px-3 py-2 flex items-center gap-3 shrink-0">
          <div className="w-20 h-12 sm:w-28 sm:h-16 shrink-0 rounded-2xl overflow-hidden">
            <AssetImage
              assetId={activeMeeting.backgroundAssetId}
              className="w-full h-full rounded-2xl"
              labelBadge={`Pertemuan ${activeMeeting.id}`}
            />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="font-extrabold text-[clamp(16px,2.8vw,24px)] text-slate-950 leading-tight truncate">
              {activeMeeting.title}
            </h2>
            <p className="text-xs sm:text-sm md:text-base font-semibold text-slate-700 truncate">
              {activeMeeting.objective}
            </p>
          </div>
        </div>

        {/* 4 Missions Grid */}
        <div className="flex-1 min-h-0 grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3">
          {activeMeeting.missions.map((mission) => {
            const isCompleted = progress.completedMissionIds.includes(mission.id);
            const unlocked = isMissionUnlocked(mission.id);
            const stars = progress.starsByMission[mission.id] || 0;

            return (
              <button
                key={mission.id}
                type="button"
                disabled={!unlocked}
                onClick={() => {
                  if (!unlocked) return;
                  playTapSound();
                  onSelectMission(mission);
                }}
                className={`w-full h-full min-h-0 rounded-3xl border-3 p-2.5 sm:p-3 flex items-center gap-3 text-left transition-transform ${
                  isCompleted
                    ? 'bg-emerald-50 border-emerald-500 hover:bg-emerald-100 active:scale-[0.98] cursor-pointer'
                    : unlocked
                      ? 'bg-[#ffc83d]/30 border-amber-500 hover:bg-[#ffc83d]/45 active:scale-[0.98] cursor-pointer shadow-sm'
                      : 'bg-slate-100 border-slate-300 opacity-75 cursor-not-allowed'
                }`}
              >
                <div className="w-14 h-14 sm:w-20 sm:h-20 shrink-0 flex items-center justify-center">
                  <AssetImage
                    assetId={mission.coverAssetId}
                    labelBadge={`Misi ${mission.meetingId}.${mission.orderInMeeting}`}
                    className="w-full h-full"
                  />
                </div>

                <div className="flex-1 min-w-0 flex flex-col justify-center">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs sm:text-sm font-extrabold text-[#0284c7]">
                      Misi {mission.meetingId}.{mission.orderInMeeting} · {mission.steamTags.join(' + ')}
                    </span>
                    {isCompleted ? (
                      <span className="flex items-center gap-1 text-xs sm:text-sm font-extrabold text-emerald-800 shrink-0">
                        <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                        <span>{stars} Bintang</span>
                      </span>
                    ) : unlocked ? (
                      <span className="flex items-center gap-1 text-xs sm:text-sm font-extrabold text-amber-900 shrink-0">
                        <Play className="w-4 h-4 fill-current" aria-hidden="true" />
                        <span>Main</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-xs sm:text-sm font-bold text-slate-600 shrink-0">
                        <Lock className="w-4 h-4" aria-hidden="true" />
                        <span>Terkunci</span>
                      </span>
                    )}
                  </div>

                  <h3 className="font-extrabold text-[clamp(17px,2.8vw,23px)] text-slate-950 leading-tight truncate mt-0.5">
                    {mission.title}
                  </h3>
                  <p className="text-xs sm:text-sm md:text-base font-semibold text-slate-700 truncate">
                    {mission.shortDesc}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Final Quiz Callout Banner */}
        <button
          type="button"
          onClick={() => {
            if (!allCompleted && !teacherUnlockAll) return;
            playTapSound();
            onNavigate('final_quiz');
          }}
          disabled={!allCompleted && !teacherUnlockAll}
          className={`w-full min-h-[50px] px-4 py-2 rounded-2xl border-2 font-extrabold text-[clamp(15px,2.6vw,20px)] flex items-center justify-center gap-2 shrink-0 ${
            allCompleted || teacherUnlockAll
              ? 'bg-[#5bcb7a] hover:bg-emerald-500 border-emerald-600 text-slate-950 cursor-pointer active:scale-[0.99]'
              : 'bg-white/80 border-slate-300 text-slate-600 cursor-not-allowed'
          }`}
        >
          <Trophy className="w-5 h-5 shrink-0" aria-hidden="true" />
          <span>
            {allCompleted || teacherUnlockAll
              ? 'Buka Kuis Akhir Penjelajah Antariksa!'
              : `Selesaikan 16 misi untuk Kuis Akhir (${progress.completedMissionIds.length}/16)`}
          </span>
        </button>
      </main>

      {/* Bottom Utility Nav */}
      <nav
        aria-label="Alat Belajar"
        className="w-full shrink-0 bg-white/95 border-t-2 border-sky-200 px-3 py-2 grid grid-cols-4 gap-2"
      >
        {[
          { page: 'glossary' as const, label: 'Glosarium', Icon: BookOpen },
          { page: 'facts' as const, label: 'Fakta Unik', Icon: Sparkles },
          { page: 'badges' as const, label: 'Hadiah', Icon: Award },
          { page: 'parent_teacher' as const, label: 'Guru / Ortu', Icon: Users },
        ].map(({ page, label, Icon }) => (
          <button
            key={page}
            type="button"
            onClick={() => {
              playTapSound();
              onNavigate(page);
            }}
            className="min-h-[46px] px-2 py-1 rounded-2xl bg-sky-50 hover:bg-sky-100 border-2 border-sky-200 text-slate-900 font-bold text-xs sm:text-sm md:text-base flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Icon className="w-5 h-5 text-[#0284c7] shrink-0" aria-hidden="true" />
            <span className="truncate">{label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};
