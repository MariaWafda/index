import React, { useState } from 'react';
import { ShieldCheck, Trash2, Unlock, Lock, Database } from 'lucide-react';
import { TopBar } from '../components/TopBar';
import { BottomNav } from '../components/BottomNav';
import { ALL_MISSIONS } from '../data/curriculum';
import { ProgressState } from '../types/app';
import { playTapSound } from '../utils/audio';

interface ParentTeacherPageProps {
  progress: ProgressState;
  teacherUnlockAll: boolean;
  onToggleTeacherUnlockAll: () => void;
  onToggleStorageEnabled: () => void;
  onResetProgress: () => void;
  isSpeaking: boolean;
  isMuted: boolean;
  onToggleSpeak: (text: string) => void;
  onToggleMute: () => void;
  onBack: () => void;
}

export const ParentTeacherPage: React.FC<ParentTeacherPageProps> = ({
  progress,
  teacherUnlockAll,
  onToggleTeacherUnlockAll,
  onToggleStorageEnabled,
  onResetProgress,
  isSpeaking,
  isMuted,
  onToggleSpeak,
  onToggleMute,
  onBack,
}) => {
  const [tab, setTab] = useState<'parent' | 'teacher'>('parent');
  const [confirmReset, setConfirmReset] = useState(false);

  const quizValues = Object.values(progress.quizRecords);
  const firstTryCount = quizValues.filter((q) => q.firstTryCorrect).length;
  const totalQuizAnswered = quizValues.length;
  const totalStars = Object.values(progress.starsByMission).reduce(
    (sum, s) => sum + s,
    0
  );

  return (
    <div className="safe-viewport w-full overflow-hidden bg-gradient-to-b from-sky-50 via-white to-slate-100 flex flex-col justify-between">
      <TopBar
        title="Ringkasan Orang Tua & Guru"
        isSpeaking={isSpeaking}
        onToggleSpeak={() =>
          onToggleSpeak(
            'Halaman ringkas untuk orang tua dan guru. Aplikasi ini aman untuk anak, tanpa akun, tanpa server, dan tanpa iklan.'
          )
        }
        isMuted={isMuted}
        onToggleMute={onToggleMute}
        onBackToMap={onBack}
      />

      <main className="flex-1 min-h-0 max-w-4xl w-full mx-auto px-3 sm:px-6 py-2 flex flex-col gap-2.5 overflow-hidden">
        {/* Segmented Tabs */}
        <div className="grid grid-cols-2 gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              playTapSound();
              setTab('parent');
            }}
            className={`min-h-[48px] px-3 rounded-2xl border-2 font-extrabold text-sm sm:text-lg cursor-pointer ${
              tab === 'parent'
                ? 'bg-[#29b1f5] border-sky-700 text-slate-950'
                : 'bg-white border-sky-200 text-slate-800'
            }`}
          >
            Untuk Orang Tua
          </button>
          <button
            type="button"
            onClick={() => {
              playTapSound();
              setTab('teacher');
            }}
            className={`min-h-[48px] px-3 rounded-2xl border-2 font-extrabold text-sm sm:text-lg cursor-pointer ${
              tab === 'teacher'
                ? 'bg-[#ffc83d] border-amber-600 text-slate-950'
                : 'bg-white border-sky-200 text-slate-800'
            }`}
          >
            Ringkasan & Kontrol Guru
          </button>
        </div>

        {tab === 'parent' ? (
          <div className="flex-1 min-h-0 flex flex-col justify-center gap-2.5">
            <div className="bg-white border-2 border-sky-200 rounded-3xl p-3 sm:p-4">
              <h1 className="font-extrabold text-[clamp(20px,3.2vw,28px)] text-slate-950">
                Panduan Singkat Orang Tua
              </h1>
              <p className="mt-1 text-sm sm:text-base md:text-lg font-semibold text-slate-800 leading-snug">
                Aplikasi IPAS Kelas 6 SD ini mendampingi anak belajar Tata Surya, Rotasi dan Revolusi Bumi, serta Siang dan Malam dalam 4 pertemuan STEAM.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div className="bg-amber-50 border-2 border-amber-300 rounded-3xl p-3">
                <h2 className="font-extrabold text-base sm:text-lg text-amber-950">
                  Kegiatan Nyata di Rumah
                </h2>
                <p className="mt-1 text-xs sm:text-sm md:text-base font-semibold text-slate-800 leading-snug">
                  Dampingi anak mencoba bola dan senter, menggambar langit malam di kertas hitam, dan membuat model tata surya dari bola kertas.
                </p>
              </div>

              <div className="bg-emerald-50 border-2 border-emerald-300 rounded-3xl p-3">
                <div className="flex items-center gap-1.5 font-extrabold text-base sm:text-lg text-emerald-950">
                  <ShieldCheck className="w-5 h-5 shrink-0" aria-hidden="true" />
                  <h2>Privasi & Keamanan Anak</h2>
                </div>
                <p className="mt-1 text-xs sm:text-sm md:text-base font-semibold text-slate-800 leading-snug">
                  Aplikasi tidak meminta nama anak, tidak memiliki akun atau login, tanpa iklan, dan berjalan lokal di perangkat tanpa mengirim data ke server.
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 min-h-0 flex flex-col justify-center gap-2">
            {/* Teacher Summary Metrics */}
            <div className="grid grid-cols-3 gap-2 shrink-0">
              <div className="bg-white border-2 border-sky-200 rounded-2xl p-2.5 text-center">
                <div className="text-xs sm:text-sm font-bold text-slate-600">Misi Selesai</div>
                <div className="font-extrabold text-xl sm:text-2xl text-slate-950 tabular-nums">
                  {progress.completedMissionIds.length}/{ALL_MISSIONS.length}
                </div>
              </div>
              <div className="bg-white border-2 border-sky-200 rounded-2xl p-2.5 text-center">
                <div className="text-xs sm:text-sm font-bold text-slate-600">Benar Awal</div>
                <div className="font-extrabold text-xl sm:text-2xl text-emerald-800 tabular-nums">
                  {firstTryCount}/{totalQuizAnswered}
                </div>
              </div>
              <div className="bg-white border-2 border-sky-200 rounded-2xl p-2.5 text-center">
                <div className="text-xs sm:text-sm font-bold text-slate-600">Total Bintang</div>
                <div className="font-extrabold text-xl sm:text-2xl text-amber-800 tabular-nums">
                  {totalStars}
                </div>
              </div>
            </div>

            {/* Reflections Snapshot */}
            <div className="bg-white border-2 border-sky-200 rounded-2xl p-2.5 shrink-0">
              <div className="font-extrabold text-sm sm:text-base text-slate-950">
                Catatan Refleksi Pertemuan:
              </div>
              <div className="mt-1 grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs sm:text-sm">
                {[1, 2, 3, 4].map((num) => {
                  const ref = progress.reflections[num];
                  return (
                    <div
                      key={num}
                      className="rounded-xl bg-sky-50 border border-sky-200 px-2 py-1"
                    >
                      <div className="font-extrabold text-sky-950">Pertemuan {num}</div>
                      <div className="font-semibold text-slate-700 truncate">
                        {ref ? `${ref.mood} · ${ref.learned}` : 'Belum diisi'}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Teacher Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  playTapSound();
                  onToggleStorageEnabled();
                }}
                className={`min-h-[48px] px-3 rounded-2xl border-2 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer ${
                  progress.storageEnabled
                    ? 'bg-emerald-100 border-emerald-500 text-emerald-950'
                    : 'bg-slate-100 border-slate-300 text-slate-800'
                }`}
              >
                <Database className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>
                  {progress.storageEnabled ? 'Simpan Lokal: Aktif' : 'Simpan Lokal: Mati'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  playTapSound();
                  onToggleTeacherUnlockAll();
                }}
                className={`min-h-[48px] px-3 rounded-2xl border-2 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer ${
                  teacherUnlockAll
                    ? 'bg-amber-200 border-amber-500 text-amber-950'
                    : 'bg-white border-sky-300 text-slate-900'
                }`}
              >
                {teacherUnlockAll ? (
                  <Unlock className="w-4 h-4 shrink-0" aria-hidden="true" />
                ) : (
                  <Lock className="w-4 h-4 shrink-0" aria-hidden="true" />
                )}
                <span>
                  {teacherUnlockAll ? 'Mode Guru: Semua Terbuka' : 'Mode Guru: Kunci Urut'}
                </span>
              </button>

              {!confirmReset ? (
                <button
                  type="button"
                  onClick={() => {
                    playTapSound();
                    setConfirmReset(true);
                  }}
                  className="min-h-[48px] px-3 rounded-2xl border-2 border-rose-300 bg-rose-50 hover:bg-rose-100 text-rose-950 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>Reset Progres</span>
                </button>
              ) : (
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      playTapSound();
                      onResetProgress();
                      setConfirmReset(false);
                    }}
                    className="min-h-[48px] px-2 rounded-2xl bg-rose-600 text-white font-extrabold text-xs sm:text-sm cursor-pointer"
                  >
                    Ya, Hapus
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      playTapSound();
                      setConfirmReset(false);
                    }}
                    className="min-h-[48px] px-2 rounded-2xl bg-slate-200 text-slate-900 font-extrabold text-xs sm:text-sm cursor-pointer"
                  >
                    Batal
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <BottomNav
        onBack={onBack}
        onNext={onBack}
        backLabel="Kembali"
        nextLabel="Ke Peta Misi"
      />
    </div>
  );
};
