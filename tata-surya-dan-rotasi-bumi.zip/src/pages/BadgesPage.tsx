import React from 'react';
import { Star, Lock, CheckCircle2 } from 'lucide-react';
import { AssetImage } from '../components/AssetImage';
import { TopBar } from '../components/TopBar';
import { BottomNav } from '../components/BottomNav';
import { AssetId, ProgressState } from '../types/app';

interface BadgesPageProps {
  progress: ProgressState;
  isSpeaking: boolean;
  isMuted: boolean;
  onToggleSpeak: (text: string) => void;
  onToggleMute: () => void;
  onBackToMap: () => void;
}

const BADGE_LIST: { id: AssetId; title: string; rule: string }[] = [
  {
    id: 'lencana_bintang',
    title: 'Lencana Bintang',
    rule: 'Terbuka setelah menyelesaikan misi pertama.',
  },
  {
    id: 'lencana_pintar',
    title: 'Lencana Pintar',
    rule: 'Terbuka setelah menyelesaikan percobaan dan simulasi.',
  },
  {
    id: 'lencana_juara',
    title: 'Lencana Juara',
    rule: 'Terbuka setelah merakit model dan menuntaskan proyek.',
  },
];

export const BadgesPage: React.FC<BadgesPageProps> = ({
  progress,
  isSpeaking,
  isMuted,
  onToggleSpeak,
  onToggleMute,
  onBackToMap,
}) => {
  const totalStars = Object.values(progress.starsByMission).reduce(
    (sum, s) => sum + s,
    0
  );

  return (
    <div className="safe-viewport w-full overflow-hidden bg-gradient-to-b from-amber-50 via-sky-50 to-emerald-50 flex flex-col justify-between">
      <TopBar
        title="Koleksi Hadiah"
        isSpeaking={isSpeaking}
        onToggleSpeak={() =>
          onToggleSpeak(
            `Koleksi hadiahmu. Kamu sudah mengumpulkan ${totalStars} bintang dan ${progress.unlockedBadges.length} lencana.`
          )
        }
        isMuted={isMuted}
        onToggleMute={onToggleMute}
        onBackToMap={onBackToMap}
      />

      <main className="flex-1 min-h-0 max-w-5xl w-full mx-auto px-3 sm:px-6 py-2 sm:py-4 flex flex-col justify-center gap-3 overflow-hidden">
        <div className="bg-white border-2 border-amber-400 rounded-3xl px-4 py-2.5 flex items-center justify-between gap-3 shrink-0">
          <div>
            <h1 className="font-extrabold text-[clamp(20px,3.6vw,32px)] text-slate-950 leading-tight">
              Hadiah Penjelajah Si Bintang
            </h1>
            <p className="text-sm sm:text-base font-bold text-slate-700">
              Selesaikan misi untuk membuka semua lencana.
            </p>
          </div>
          <div className="px-3.5 py-2 rounded-2xl bg-amber-100 border-2 border-amber-500 text-amber-950 font-extrabold text-lg sm:text-2xl flex items-center gap-1.5 shrink-0 tabular-nums">
            <Star className="w-6 h-6 fill-amber-400 text-amber-600" aria-hidden="true" />
            <span>{totalStars}/48</span>
          </div>
        </div>

        <div className="flex-1 min-h-0 grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-4">
          {BADGE_LIST.map((badge) => {
            const unlocked = progress.unlockedBadges.includes(badge.id);
            return (
              <div
                key={badge.id}
                className={`rounded-3xl border-3 p-3 flex sm:flex-col items-center justify-center gap-3 text-left sm:text-center min-h-0 ${
                  unlocked
                    ? 'bg-white border-emerald-500 shadow-sm'
                    : 'bg-slate-100/90 border-slate-300 opacity-80'
                }`}
              >
                <div className="w-16 h-16 sm:w-32 sm:h-32 shrink-0 flex items-center justify-center">
                  <AssetImage
                    assetId={badge.id}
                    animation={unlocked ? 'bounce' : 'none'}
                    labelBadge={badge.title}
                    className={`w-full h-full ${unlocked ? '' : 'grayscale opacity-50'}`}
                  />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center sm:justify-center gap-1 text-xs sm:text-sm font-extrabold">
                    {unlocked ? (
                      <span className="text-emerald-800 flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                        Terbuka
                      </span>
                    ) : (
                      <span className="text-slate-600 flex items-center gap-1">
                        <Lock className="w-4 h-4" aria-hidden="true" />
                        Belum Terbuka
                      </span>
                    )}
                  </div>
                  <h2 className="font-extrabold text-[clamp(17px,2.8vw,24px)] text-slate-950 leading-tight mt-0.5">
                    {badge.title}
                  </h2>
                  <p className="text-xs sm:text-sm font-semibold text-slate-700 leading-snug mt-0.5">
                    {badge.rule}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      <BottomNav
        onBack={onBackToMap}
        onNext={onBackToMap}
        backLabel="Peta"
        nextLabel="Lanjut Main"
      />
    </div>
  );
};
