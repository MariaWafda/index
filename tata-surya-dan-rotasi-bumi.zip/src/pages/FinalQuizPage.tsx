import React, { useState } from 'react';
import { Award } from 'lucide-react';
import { FINAL_QUIZ_QUESTIONS } from '../data/curriculum';
import { TopBar } from '../components/TopBar';
import { BottomNav } from '../components/BottomNav';
import { QuizQuestionView } from '../components/interactions/QuizQuestionView';
import { AssetImage } from '../components/AssetImage';
import { playCelebrationSound } from '../utils/audio';

interface FinalQuizPageProps {
  isSpeaking: boolean;
  isMuted: boolean;
  onToggleSpeak: (text: string) => void;
  onStopSpeak: () => void;
  onToggleMute: () => void;
  onBackToMap: () => void;
  onFinishFinalQuiz: (correctFirstTry: number, total: number) => void;
}

export const FinalQuizPage: React.FC<FinalQuizPageProps> = ({
  isSpeaking,
  isMuted,
  onToggleSpeak,
  onStopSpeak,
  onToggleMute,
  onBackToMap,
  onFinishFinalQuiz,
}) => {
  const [step, setStep] = useState<number>(0);
  const [answeredMap, setAnsweredMap] = useState<Record<string, boolean>>({});
  const [firstTryMap, setFirstTryMap] = useState<Record<string, boolean>>({});

  const isSummary = step >= FINAL_QUIZ_QUESTIONS.length;
  const currentQ = FINAL_QUIZ_QUESTIONS[step];

  const handleNext = () => {
    onStopSpeak();
    if (isSummary) {
      onBackToMap();
      return;
    }
    const nextStep = step + 1;
    setStep(nextStep);
    if (nextStep >= FINAL_QUIZ_QUESTIONS.length) {
      const firstTryCount = Object.values(firstTryMap).filter(Boolean).length;
      playCelebrationSound();
      onFinishFinalQuiz(firstTryCount, FINAL_QUIZ_QUESTIONS.length);
    }
  };

  const handleBack = () => {
    onStopSpeak();
    if (step === 0) {
      onBackToMap();
    } else {
      setStep((s) => Math.max(0, s - 1));
    }
  };

  return (
    <div className="safe-viewport w-full overflow-hidden bg-gradient-to-b from-sky-100 via-sky-50 to-emerald-50 flex flex-col justify-between">
      <TopBar
        currentStep={Math.min(step, FINAL_QUIZ_QUESTIONS.length)}
        totalSteps={FINAL_QUIZ_QUESTIONS.length + 1}
        isSpeaking={isSpeaking}
        onToggleSpeak={() =>
          onToggleSpeak(
            isSummary
              ? 'Selamat! Kamu menyelesaikan Kuis Akhir Penjelajah Antariksa dengan penuh semangat. Bertumbuh Bersama Kita Bisa.'
              : `${currentQ.title}. ${currentQ.question}`
          )
        }
        isMuted={isMuted}
        onToggleMute={onToggleMute}
        onBackToMap={onBackToMap}
      />

      <main className="flex-1 min-h-0 max-w-5xl w-full mx-auto px-4 py-3 flex items-center justify-center overflow-hidden">
        {isSummary ? (
          <div className="w-full h-full flex flex-col md:grid md:grid-cols-12 items-center justify-center gap-4 min-h-0">
            <div className="md:col-span-5 flex-1 md:flex-none min-h-0 flex items-center justify-center max-h-[38vh] md:max-h-[58vh]">
              <AssetImage
                assetId="lencana_juara"
                animation="bounce"
                labelBadge="Lencana Juara Kuis Akhir"
                className="w-full h-full max-h-full"
              />
            </div>
            <div className="md:col-span-7 flex flex-col items-center md:items-start text-center md:text-left gap-2 shrink-0">
              <div className="flex items-center gap-2 text-emerald-800 font-extrabold text-lg sm:text-xl">
                <Award className="w-6 h-6" aria-hidden="true" />
                <span>Kuis Akhir Tuntas!</span>
              </div>
              <h1 className="font-extrabold text-[clamp(26px,4.5vw,44px)] text-slate-950 leading-tight">
                Hebat, Penjelajah Antariksa!
              </h1>
              <p className="font-bold text-[clamp(18px,3.2vw,26px)] text-slate-800 leading-snug">
                Kamu telah menyelesaikan semua tantangan akhir dengan baik. Teruslah bertanya dan mengamati alam sekitar!
              </p>
              <div className="mt-1 px-4 py-2 rounded-2xl bg-amber-100 border-2 border-amber-400 text-amber-950 font-extrabold text-base sm:text-xl">
                Bertumbuh Bersama Kita Bisa
              </div>
            </div>
          </div>
        ) : (
          <QuizQuestionView
            questionData={currentQ}
            onSpeakText={(txt) => onToggleSpeak(txt)}
            onAnsweredCorrectly={(firstTry) => {
              setAnsweredMap((prev) => ({ ...prev, [currentQ.id]: true }));
              setFirstTryMap((prev) => ({ ...prev, [currentQ.id]: firstTry }));
            }}
          />
        )}
      </main>

      <BottomNav
        onBack={handleBack}
        onNext={handleNext}
        backLabel={step === 0 ? 'Peta' : 'Kembali'}
        nextLabel={isSummary ? 'Ke Peta' : 'Lanjut'}
        nextDisabled={!isSummary && !answeredMap[currentQ.id]}
      />
    </div>
  );
};
