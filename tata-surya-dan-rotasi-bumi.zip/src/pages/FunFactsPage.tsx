import React, { useState } from 'react';
import { FUN_FACTS } from '../data/solarSystem';
import { AssetImage } from '../components/AssetImage';
import { TopBar } from '../components/TopBar';
import { BottomNav } from '../components/BottomNav';

interface FunFactsPageProps {
  isSpeaking: boolean;
  isMuted: boolean;
  onToggleSpeak: (text: string) => void;
  onToggleMute: () => void;
  onBackToMap: () => void;
}

export const FunFactsPage: React.FC<FunFactsPageProps> = ({
  isSpeaking,
  isMuted,
  onToggleSpeak,
  onToggleMute,
  onBackToMap,
}) => {
  const [index, setIndex] = useState(0);
  const fact = FUN_FACTS[index] || FUN_FACTS[0];

  const speakText = `Fakta Unik. ${fact.title}. ${fact.fact}`;

  return (
    <div className="safe-viewport w-full overflow-hidden bg-gradient-to-b from-amber-50 via-sky-50 to-emerald-50 flex flex-col justify-between">
      <TopBar
        currentStep={index}
        totalSteps={FUN_FACTS.length}
        isSpeaking={isSpeaking}
        onToggleSpeak={() => onToggleSpeak(speakText)}
        isMuted={isMuted}
        onToggleMute={onToggleMute}
        onBackToMap={onBackToMap}
      />

      <main className="flex-1 min-h-0 max-w-5xl w-full mx-auto px-4 py-3 flex flex-col md:grid md:grid-cols-12 items-center justify-center gap-4 overflow-hidden">
        <div className="md:col-span-6 w-full flex-1 md:flex-none min-h-0 flex items-center justify-center max-h-[38vh] md:max-h-[58vh]">
          <AssetImage
            assetId={fact.assetId}
            animation="bounce"
            labelBadge={fact.title}
            className="w-full h-full max-h-full"
          />
        </div>

        <div className="md:col-span-6 w-full flex flex-col items-center md:items-start text-center md:text-left gap-2 shrink-0">
          <span className="text-sm sm:text-base font-extrabold text-[#0284c7]">
            Fakta Unik Antariksa · {index + 1} dari {FUN_FACTS.length}
          </span>
          <h1 className="font-extrabold text-[clamp(26px,4.5vw,44px)] text-slate-950 leading-tight">
            {fact.title}
          </h1>
          <p className="font-bold text-[clamp(20px,3.5vw,28px)] text-slate-800 leading-snug">
            {fact.fact}
          </p>
        </div>
      </main>

      <BottomNav
        onBack={() => {
          if (index === 0) onBackToMap();
          else setIndex((i) => i - 1);
        }}
        onNext={() => {
          if (index === FUN_FACTS.length - 1) onBackToMap();
          else setIndex((i) => i + 1);
        }}
        backLabel={index === 0 ? 'Peta' : 'Kembali'}
        nextLabel={index === FUN_FACTS.length - 1 ? 'Selesai' : 'Lanjut'}
      />
    </div>
  );
};
