import { useEffect, useState } from 'react';
import { AppPage, AssetId, Mission, ProgressState } from './types/app';
import {
  clearProgress,
  loadProgress,
  saveProgress,
} from './utils/storage';
import {
  setSoundMuted,
  speakIndonesian,
  stopSpeaking,
} from './utils/audio';
import { preloadAsset } from './data/assets';
import { WelcomePage } from './pages/WelcomePage';
import { MissionMapPage } from './pages/MissionMapPage';
import { MissionRunnerPage } from './pages/MissionRunnerPage';
import { GlossaryPage } from './pages/GlossaryPage';
import { FunFactsPage } from './pages/FunFactsPage';
import { FinalQuizPage } from './pages/FinalQuizPage';
import { BadgesPage } from './pages/BadgesPage';
import { ParentTeacherPage } from './pages/ParentTeacherPage';
import { AssetGalleryPage } from './pages/AssetGalleryPage';

function isAssetGalleryUrl(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.location.pathname === '/galeri-aset' ||
    window.location.hash === '#/galeri-aset'
  );
}

export default function App() {
  const [page, setPage] = useState<AppPage>(() =>
    isAssetGalleryUrl() ? 'asset_gallery' : 'welcome'
  );
  const [progress, setProgress] = useState<ProgressState>(() => loadProgress());
  const [activeMission, setActiveMission] = useState<Mission | null>(null);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [reduceMotion, setReduceMotion] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    return false;
  });
  const [teacherUnlockAll, setTeacherUnlockAll] = useState<boolean>(false);

  // Sync URL popstate for /galeri-aset
  useEffect(() => {
    const onPopState = () => {
      if (isAssetGalleryUrl()) {
        setPage('asset_gallery');
      } else if (page === 'asset_gallery') {
        setPage('welcome');
      }
    };
    window.addEventListener('popstate', onPopState);
    window.addEventListener('hashchange', onPopState);
    return () => {
      window.removeEventListener('popstate', onPopState);
      window.removeEventListener('hashchange', onPopState);
    };
  }, [page]);

  // Preload initial key images
  useEffect(() => {
    preloadAsset('sampul');
    preloadAsset('latar_pertemuan_1');
  }, []);

  // Persist progress whenever it changes
  useEffect(() => {
    saveProgress(progress);
  }, [progress]);

  // Stop speech when leaving page
  const navigateTo = (nextPage: AppPage) => {
    stopSpeaking();
    setIsSpeaking(false);
    setPage(nextPage);
  };

  const handleToggleSpeak = (text: string) => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }
    setIsSpeaking(true);
    const started = speakIndonesian(text, () => {
      setIsSpeaking(false);
    });
    if (!started) {
      setIsSpeaking(false);
    }
  };

  const handleStopSpeak = () => {
    stopSpeaking();
    setIsSpeaking(false);
  };

  const handleToggleMute = () => {
    setIsMuted((prev) => {
      const next = !prev;
      setSoundMuted(next);
      if (next) setIsSpeaking(false);
      return next;
    });
  };

  const handleSelectMission = (mission: Mission) => {
    handleStopSpeak();
    setActiveMission(mission);
    setPage('mission');
  };

  const handleRecordQuizAnswer = (
    missionId: string,
    questionId: string,
    firstTryCorrect: boolean,
    attempts: number,
    selectedReason?: string
  ) => {
    setProgress((prev) => ({
      ...prev,
      quizRecords: {
        ...prev.quizRecords,
        [questionId]: {
          questionId,
          missionId,
          firstTryCorrect,
          attempts,
          selectedReason,
        },
      },
    }));
  };

  const handleSavePracticeObservation = (screenId: string, observation: string) => {
    setProgress((prev) => ({
      ...prev,
      practiceObservations: {
        ...prev.practiceObservations,
        [screenId]: observation,
      },
    }));
  };

  const handleSaveReflection = (
    meetingNumber: 1 | 2 | 3 | 4,
    mood: 'senang' | 'paham' | 'bingung',
    learned: string
  ) => {
    setProgress((prev) => ({
      ...prev,
      reflections: {
        ...prev.reflections,
        [meetingNumber]: {
          meetingNumber,
          mood,
          learned,
          updatedAt: new Date().toISOString(),
        },
      },
    }));
  };

  const handleCompleteMission = (mission: Mission, badgeId: AssetId) => {
    setProgress((prev) => {
      const completed = prev.completedMissionIds.includes(mission.id)
        ? prev.completedMissionIds
        : [...prev.completedMissionIds, mission.id];
      const badges = prev.unlockedBadges.includes(badgeId)
        ? prev.unlockedBadges
        : [...prev.unlockedBadges, badgeId];
      return {
        ...prev,
        completedMissionIds: completed,
        starsByMission: {
          ...prev.starsByMission,
          [mission.id]: 3,
        },
        unlockedBadges: badges,
      };
    });
  };

  const handleFinishFinalQuiz = (correctFirstTry: number, total: number) => {
    setProgress((prev) => {
      const badges: AssetId[] = prev.unlockedBadges.includes('lencana_juara')
        ? prev.unlockedBadges
        : [...prev.unlockedBadges, 'lencana_juara'];
      return {
        ...prev,
        finalQuizCompleted: true,
        finalQuizCorrectFirstTry: correctFirstTry,
        finalQuizTotal: total,
        unlockedBadges: badges,
      };
    });
  };

  const handleToggleStorageEnabled = () => {
    setProgress((prev) => ({
      ...prev,
      storageEnabled: !prev.storageEnabled,
    }));
  };

  const handleResetProgress = () => {
    const fresh = clearProgress();
    setProgress({ ...fresh, storageEnabled: progress.storageEnabled });
    setTeacherUnlockAll(false);
  };

  return (
    <div className={reduceMotion ? 'reduce-motion' : ''}>
      {page === 'asset_gallery' && (
        <AssetGalleryPage
          onBackToApp={() => {
            if (window.location.pathname === '/galeri-aset') {
              window.history.pushState({}, '', '/');
            } else if (window.location.hash === '#/galeri-aset') {
              window.history.pushState({}, '', '#/');
            }
            navigateTo('welcome');
          }}
        />
      )}

      {page === 'welcome' && (
        <WelcomePage
          onStart={() => navigateTo('map')}
          onNavigate={navigateTo}
          isSpeaking={isSpeaking}
          onToggleSpeak={handleToggleSpeak}
          reduceMotion={reduceMotion}
          onToggleReduceMotion={() => setReduceMotion((r) => !r)}
        />
      )}

      {page === 'map' && (
        <MissionMapPage
          progress={progress}
          teacherUnlockAll={teacherUnlockAll}
          onSelectMission={handleSelectMission}
          onNavigate={navigateTo}
          isSpeaking={isSpeaking}
          onToggleSpeak={handleToggleSpeak}
        />
      )}

      {page === 'mission' && activeMission && (
        <MissionRunnerPage
          mission={activeMission}
          progress={progress}
          reduceMotion={reduceMotion}
          isSpeaking={isSpeaking}
          isMuted={isMuted}
          onToggleSpeak={handleToggleSpeak}
          onStopSpeak={handleStopSpeak}
          onToggleMute={handleToggleMute}
          onExitToMap={() => navigateTo('map')}
          onRecordQuizAnswer={handleRecordQuizAnswer}
          onSavePracticeObservation={handleSavePracticeObservation}
          onSaveReflection={handleSaveReflection}
          onCompleteMission={handleCompleteMission}
        />
      )}

      {page === 'glossary' && (
        <GlossaryPage
          isSpeaking={isSpeaking}
          isMuted={isMuted}
          onToggleSpeak={handleToggleSpeak}
          onToggleMute={handleToggleMute}
          onBackToMap={() => navigateTo('map')}
        />
      )}

      {page === 'facts' && (
        <FunFactsPage
          isSpeaking={isSpeaking}
          isMuted={isMuted}
          onToggleSpeak={handleToggleSpeak}
          onToggleMute={handleToggleMute}
          onBackToMap={() => navigateTo('map')}
        />
      )}

      {page === 'final_quiz' && (
        <FinalQuizPage
          isSpeaking={isSpeaking}
          isMuted={isMuted}
          onToggleSpeak={handleToggleSpeak}
          onStopSpeak={handleStopSpeak}
          onToggleMute={handleToggleMute}
          onBackToMap={() => navigateTo('map')}
          onFinishFinalQuiz={handleFinishFinalQuiz}
        />
      )}

      {page === 'badges' && (
        <BadgesPage
          progress={progress}
          isSpeaking={isSpeaking}
          isMuted={isMuted}
          onToggleSpeak={handleToggleSpeak}
          onToggleMute={handleToggleMute}
          onBackToMap={() => navigateTo('map')}
        />
      )}

      {page === 'parent_teacher' && (
        <ParentTeacherPage
          progress={progress}
          teacherUnlockAll={teacherUnlockAll}
          onToggleTeacherUnlockAll={() => setTeacherUnlockAll((v) => !v)}
          onToggleStorageEnabled={handleToggleStorageEnabled}
          onResetProgress={handleResetProgress}
          isSpeaking={isSpeaking}
          isMuted={isMuted}
          onToggleSpeak={handleToggleSpeak}
          onToggleMute={handleToggleMute}
          onBack={() => navigateTo('map')}
        />
      )}
    </div>
  );
}
