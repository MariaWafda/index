import { AssetId, ProgressState } from '../types/app';

const STORAGE_KEY = 'tata_surya_rotasi_bumi_v1';

export const DEFAULT_PROGRESS: ProgressState = {
  completedMissionIds: [],
  starsByMission: {},
  unlockedBadges: [],
  quizRecords: {},
  finalQuizCompleted: false,
  finalQuizCorrectFirstTry: 0,
  finalQuizTotal: 0,
  reflections: {},
  practiceObservations: {},
  storageEnabled: true,
};

export function loadProgress(): ProgressState {
  if (typeof window === 'undefined') return DEFAULT_PROGRESS;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PROGRESS;
    const parsed = JSON.parse(raw) as Partial<ProgressState>;
    if (parsed.storageEnabled === false) {
      return { ...DEFAULT_PROGRESS, storageEnabled: false };
    }
    return {
      ...DEFAULT_PROGRESS,
      ...parsed,
      completedMissionIds: Array.isArray(parsed.completedMissionIds) ? parsed.completedMissionIds : [],
      starsByMission: parsed.starsByMission || {},
      unlockedBadges: Array.isArray(parsed.unlockedBadges) ? (parsed.unlockedBadges as AssetId[]) : [],
      quizRecords: parsed.quizRecords || {},
      reflections: parsed.reflections || {},
      practiceObservations: parsed.practiceObservations || {},
      storageEnabled: true,
    };
  } catch {
    return DEFAULT_PROGRESS;
  }
}

export function saveProgress(state: ProgressState): void {
  if (typeof window === 'undefined') return;
  try {
    if (!state.storageEnabled) {
      window.localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ ...DEFAULT_PROGRESS, storageEnabled: false })
      );
      return;
    }
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage quota errors
  }
}

export function clearProgress(): ProgressState {
  if (typeof window !== 'undefined') {
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch {
      // Ignore
    }
  }
  return { ...DEFAULT_PROGRESS };
}
