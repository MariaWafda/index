import React, { useEffect, useState } from 'react';
import { ASSET_MAP } from '../data/assets';
import { AssetId } from '../types/app';

interface AssetImageProps {
  assetId: AssetId;
  className?: string;
  imgClassName?: string;
  animation?: 'float' | 'bounce' | 'sway' | 'fade' | 'none';
  style?: React.CSSProperties;
  decorative?: boolean;
  labelBadge?: string;
}

const PASTEL_STYLES: Record<string, string> = {
  scene: 'bg-sky-100 border-sky-300 text-sky-900',
  background: 'bg-amber-50 border-amber-200 text-amber-900',
  object: 'bg-amber-100 border-amber-300 text-amber-950',
  badge: 'bg-emerald-100 border-emerald-300 text-emerald-950',
};

export const AssetImage: React.FC<AssetImageProps> = ({
  assetId,
  className = '',
  imgClassName = '',
  animation = 'none',
  style,
  decorative = false,
  labelBadge,
}) => {
  const item = ASSET_MAP[assetId];
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    setHasError(false);
  }, [assetId]);

  if (!item) return null;

  const isWide = item.aspect_ratio === '16:9';
  const animClass =
    animation === 'float'
      ? 'anim-float'
      : animation === 'bounce'
        ? 'anim-bounce'
        : animation === 'sway'
          ? 'anim-sway'
          : animation === 'fade'
            ? 'anim-fade'
            : '';

  if (hasError) {
    const pastel = PASTEL_STYLES[item.kind] || PASTEL_STYLES.object;
    return (
      <div
        role="img"
        aria-label={decorative ? '' : item.alt_text}
        style={style}
        className={`flex flex-col items-center justify-center rounded-3xl border-4 border-dashed p-3 text-center select-none ${pastel} ${animClass} ${className}`}
      >
        <span className="text-[clamp(18px,3.2vw,24px)] font-bold leading-snug">
          {labelBadge || item.alt_text}
        </span>
        <span className="mt-1 text-xs font-medium opacity-75 break-all">
          {item.file}
        </span>
      </div>
    );
  }

  return (
    <img
      src={item.file}
      alt={decorative ? '' : item.alt_text}
      width={isWide ? 1280 : 800}
      height={isWide ? 720 : 800}
      onError={() => setHasError(true)}
      style={style}
      className={`object-contain select-none ${animClass} ${imgClassName} ${className}`}
      draggable={false}
    />
  );
};
