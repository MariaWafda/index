import React from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { playTapSound } from '../utils/audio';

interface BottomNavProps {
  onBack?: () => void;
  onNext?: () => void;
  backLabel?: string;
  nextLabel?: string;
  backDisabled?: boolean;
  nextDisabled?: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  onBack,
  onNext,
  backLabel = 'Kembali',
  nextLabel = 'Lanjut',
  backDisabled = false,
  nextDisabled = false,
}) => {
  return (
    <footer className="w-full shrink-0 bg-white/95 border-t-2 border-sky-200 px-3 py-2.5 flex items-center justify-between gap-3 z-20">
      <button
        type="button"
        onClick={() => {
          if (backDisabled || !onBack) return;
          playTapSound();
          onBack();
        }}
        disabled={backDisabled || !onBack}
        className={`flex-1 max-w-[220px] min-h-[56px] px-4 py-2 rounded-2xl border-2 font-extrabold text-[clamp(20px,4.5vw,28px)] leading-none flex items-center justify-center gap-2 transition-transform active:scale-95 whitespace-nowrap cursor-pointer ${
          backDisabled || !onBack
            ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed active:scale-100'
            : 'bg-sky-100 hover:bg-sky-200 border-sky-400 text-sky-950'
        }`}
      >
        <ArrowLeft className="w-6 h-6 shrink-0" aria-hidden="true" />
        <span>{backLabel}</span>
      </button>

      <button
        type="button"
        onClick={() => {
          if (nextDisabled || !onNext) return;
          playTapSound();
          onNext();
        }}
        disabled={nextDisabled || !onNext}
        className={`flex-1 max-w-[260px] min-h-[56px] px-4 py-2 rounded-2xl border-2 font-extrabold text-[clamp(20px,4.5vw,28px)] leading-none flex items-center justify-center gap-2 transition-transform active:scale-95 whitespace-nowrap cursor-pointer ${
          nextDisabled || !onNext
            ? 'bg-slate-200 border-slate-300 text-slate-500 cursor-not-allowed active:scale-100'
            : 'bg-[#5bcb7a] hover:bg-emerald-500 border-emerald-600 text-slate-950 shadow-sm'
        }`}
      >
        <span>{nextLabel}</span>
        <ArrowRight className="w-6 h-6 shrink-0" aria-hidden="true" />
      </button>
    </footer>
  );
};
