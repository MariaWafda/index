import React from 'react';
import { Map, Volume2, VolumeX, Speech, Square } from 'lucide-react';
import { playTapSound } from '../utils/audio';

interface TopBarProps {
  title?: string;
  currentStep?: number;
  totalSteps?: number;
  isSpeaking: boolean;
  onToggleSpeak: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onBackToMap?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  title,
  currentStep,
  totalSteps,
  isSpeaking,
  onToggleSpeak,
  isMuted,
  onToggleMute,
  onBackToMap,
}) => {
  const hasProgress =
    typeof currentStep === 'number' &&
    typeof totalSteps === 'number' &&
    totalSteps > 0;

  return (
    <header className="w-full shrink-0 bg-white/95 border-b-2 border-sky-200 px-3 py-2 flex items-center justify-between gap-2 z-20">
      <div className="flex items-center gap-2 min-w-0">
        {onBackToMap && (
          <button
            type="button"
            onClick={() => {
              playTapSound();
              onBackToMap();
            }}
            className="min-h-[44px] px-3 rounded-2xl bg-sky-100 hover:bg-sky-200 active:scale-95 text-sky-900 font-bold text-base sm:text-lg flex items-center gap-1.5 transition-transform shrink-0 cursor-pointer"
            aria-label="Kembali ke peta misi"
          >
            <Map className="w-5 h-5 shrink-0" aria-hidden="true" />
            <span className="whitespace-nowrap">Peta</span>
          </button>
        )}

        {hasProgress ? (
          <div className="flex items-center gap-2 min-w-0">
            <div
              className="hidden sm:flex items-center gap-1"
              aria-label={`Langkah ${currentStep + 1} dari ${totalSteps}`}
            >
              {Array.from({ length: totalSteps }).map((_, idx) => {
                const active = idx === currentStep;
                const done = idx < currentStep;
                return (
                  <span
                    key={idx}
                    className={`h-3 rounded-full transition-all ${
                      active
                        ? 'w-7 bg-[#29b1f5]'
                        : done
                          ? 'w-3 bg-[#5bcb7a]'
                          : 'w-3 bg-slate-200'
                    }`}
                  />
                );
              })}
            </div>
            <div className="flex sm:hidden items-center gap-2">
              <div className="w-20 h-3 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#29b1f5] rounded-full transition-all"
                  style={{ width: `${Math.round(((currentStep + 1) / totalSteps) * 100)}%` }}
                />
              </div>
              <span className="text-sm font-extrabold text-slate-700 tabular-nums whitespace-nowrap">
                {currentStep + 1}/{totalSteps}
              </span>
            </div>
          </div>
        ) : title ? (
          <span className="font-extrabold text-slate-900 text-lg sm:text-xl truncate">
            {title}
          </span>
        ) : null}
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={() => {
            playTapSound();
            onToggleSpeak();
          }}
          className={`min-h-[44px] px-3 rounded-2xl font-bold text-base sm:text-lg flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer ${
            isSpeaking
              ? 'bg-rose-100 text-rose-900 border-2 border-rose-400'
              : 'bg-[#ffc83d] hover:bg-amber-400 text-slate-950 border-2 border-amber-500'
          }`}
          aria-label={isSpeaking ? 'Hentikan suara bacaan' : 'Bacakan teks layar'}
        >
          {isSpeaking ? (
            <>
              <Square className="w-5 h-5 shrink-0 fill-current" aria-hidden="true" />
              <span className="whitespace-nowrap">Henti</span>
            </>
          ) : (
            <>
              <Speech className="w-5 h-5 shrink-0" aria-hidden="true" />
              <span className="whitespace-nowrap">Baca</span>
            </>
          )}
        </button>

        <button
          type="button"
          onClick={onToggleMute}
          className={`min-h-[44px] px-3 rounded-2xl font-bold text-base sm:text-lg flex items-center gap-1.5 border-2 transition-transform active:scale-95 cursor-pointer ${
            isMuted
              ? 'bg-slate-100 text-slate-700 border-slate-300'
              : 'bg-emerald-100 text-emerald-950 border-emerald-400'
          }`}
          aria-label={isMuted ? 'Nyalakan efek suara' : 'Bisukan efek suara'}
        >
          {isMuted ? (
            <>
              <VolumeX className="w-5 h-5 shrink-0" aria-hidden="true" />
              <span className="hidden sm:inline whitespace-nowrap">Bisu</span>
            </>
          ) : (
            <>
              <Volume2 className="w-5 h-5 shrink-0" aria-hidden="true" />
              <span className="hidden sm:inline whitespace-nowrap">Suara</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
