import React, { useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { CELESTIAL_BODIES } from '../../data/solarSystem';
import { AssetImage } from '../AssetImage';
import { playTapSound } from '../../utils/audio';

interface SolarMapViewProps {
  title: string;
  text: string;
  onExploreCountChange?: (count: number) => void;
  onSpeakText?: (text: string) => void;
}

export const SolarMapView: React.FC<SolarMapViewProps> = ({
  title,
  text,
  onExploreCountChange,
  onSpeakText,
}) => {
  const [selectedId, setSelectedId] = useState<string>('matahari');
  const [visited, setVisited] = useState<string[]>(['matahari']);

  const selected =
    CELESTIAL_BODIES.find((b) => b.id === selectedId) || CELESTIAL_BODIES[0];

  const handleSelect = (id: string) => {
    playTapSound();
    setSelectedId(id);
    if (!visited.includes(id)) {
      const next = [...visited, id];
      setVisited(next);
      onExploreCountChange?.(next.length);
    }
    const body = CELESTIAL_BODIES.find((b) => b.id === id);
    if (body && onSpeakText) {
      onSpeakText(`${body.name}. ${body.role}. ${body.shortFact}`);
    }
  };

  return (
    <div className="w-full h-full flex flex-col md:grid md:grid-cols-12 gap-3 min-h-0 overflow-hidden">
      {/* Left/Top: Selector Map */}
      <div className="md:col-span-6 flex flex-col justify-center gap-2 min-h-0">
        <div className="text-center md:text-left">
          <h2 className="font-extrabold text-[clamp(22px,4vw,32px)] text-slate-950 leading-tight">
            {title}
          </h2>
          <p className="text-[clamp(16px,2.8vw,22px)] font-semibold text-slate-700 leading-snug">
            {text}
          </p>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {CELESTIAL_BODIES.map((body) => {
            const isSelected = body.id === selectedId;
            const isVisited = visited.includes(body.id);
            return (
              <button
                key={body.id}
                type="button"
                onClick={() => handleSelect(body.id)}
                className={`min-h-[46px] px-2 py-1.5 rounded-2xl border-2 font-bold text-[clamp(14px,2.6vw,19px)] flex items-center justify-center gap-1 transition-transform active:scale-95 cursor-pointer ${
                  isSelected
                    ? 'bg-[#ffc83d] border-amber-600 text-slate-950 shadow-sm'
                    : isVisited
                      ? 'bg-emerald-50 border-emerald-400 text-emerald-950'
                      : 'bg-white border-sky-200 text-slate-900 hover:bg-sky-50'
                }`}
              >
                <span className="truncate">{body.name}</span>
                {isVisited && !isSelected && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" aria-hidden="true" />
                )}
              </button>
            );
          })}
        </div>

        <p className="text-xs sm:text-sm font-semibold text-slate-600 bg-sky-50 border border-sky-200 rounded-xl px-3 py-1.5">
          Catatan jujur: Jarak di peta dirapatkan agar semua planet terlihat. Sudah dibuka: {visited.length} dari {CELESTIAL_BODIES.length}.
        </p>
      </div>

      {/* Right/Bottom: Selected Body Details */}
      <div className="md:col-span-6 flex-1 min-h-0 bg-white border-2 border-sky-200 rounded-3xl p-3 sm:p-4 flex flex-row md:flex-col items-center justify-center gap-3 overflow-hidden">
        <div className="w-24 h-24 sm:w-36 sm:h-36 md:w-44 md:h-44 shrink-0 flex items-center justify-center">
          <AssetImage
            assetId={selected.assetId}
            animation="float"
            labelBadge={selected.name}
            className="w-full h-full"
          />
        </div>
        <div className="flex-1 md:flex-none text-left md:text-center min-w-0">
          <div className="text-sm sm:text-base font-extrabold text-[#0284c7]">
            {selected.role}
          </div>
          <h3 className="font-extrabold text-[clamp(22px,3.8vw,32px)] text-slate-950 leading-tight">
            {selected.name}
          </h3>
          <p className="mt-1 font-bold text-[clamp(16px,2.8vw,22px)] text-slate-800 leading-snug">
            {selected.shortFact}
          </p>
        </div>
      </div>
    </div>
  );
};
