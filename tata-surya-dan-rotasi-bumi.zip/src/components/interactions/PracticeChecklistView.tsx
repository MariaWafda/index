import React, { useState } from 'react';
import { CheckSquare, Square, ClipboardCheck } from 'lucide-react';
import { AssetId } from '../../types/app';
import { AssetImage } from '../AssetImage';
import { playCorrectSound, playTapSound } from '../../utils/audio';

interface PracticeChecklistViewProps {
  title: string;
  text: string;
  assetId: AssetId;
  mediaNote: string;
  steps: string[];
  observationPrompt: string;
  observationOptions: string[];
  savedObservation?: string;
  onSaveObservation: (obs: string) => void;
}

export const PracticeChecklistView: React.FC<PracticeChecklistViewProps> = ({
  title,
  text,
  assetId,
  mediaNote,
  steps,
  observationPrompt,
  observationOptions,
  savedObservation = '',
  onSaveObservation,
}) => {
  const [checkedSteps, setCheckedSteps] = useState<boolean[]>(
    () => steps.map(() => false)
  );
  const [selectedObs, setSelectedObs] = useState<string>(savedObservation);
  const [viewTab, setViewTab] = useState<'steps' | 'observe'>('steps');

  const toggleStep = (idx: number) => {
    playTapSound();
    setCheckedSteps((prev) => {
      const copy = [...prev];
      copy[idx] = !copy[idx];
      return copy;
    });
  };

  const doneCount = checkedSteps.filter(Boolean).length;

  return (
    <div className="w-full h-full flex flex-col md:grid md:grid-cols-12 gap-3 min-h-0 overflow-hidden">
      {/* Left/Top Info + Asset */}
      <div className="md:col-span-5 flex flex-row md:flex-col items-center justify-center gap-3 bg-white border-2 border-sky-200 rounded-3xl p-3 shrink-0 md:shrink">
        <div className="w-20 h-20 sm:w-28 sm:h-28 md:w-40 md:h-40 shrink-0 flex items-center justify-center">
          <AssetImage
            assetId={assetId}
            animation="float"
            className="w-full h-full"
          />
        </div>
        <div className="min-w-0 text-left md:text-center">
          <h2 className="font-extrabold text-[clamp(18px,3.4vw,26px)] text-slate-950 leading-tight">
            {title}
          </h2>
          <p className="mt-0.5 text-[clamp(14px,2.4vw,18px)] font-semibold text-slate-700 leading-snug">
            {text}
          </p>
          <div className="mt-1.5 text-xs sm:text-sm font-extrabold text-amber-950 bg-amber-100 border border-amber-400 rounded-xl px-2.5 py-1 inline-block">
            {mediaNote}
          </div>
        </div>
      </div>

      {/* Right/Bottom Interactive Tabs: Steps vs Observation */}
      <div className="md:col-span-7 flex-1 min-h-0 flex flex-col gap-2 overflow-hidden">
        <div className="grid grid-cols-2 gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              playTapSound();
              setViewTab('steps');
            }}
            className={`min-h-[44px] px-3 rounded-2xl border-2 font-extrabold text-sm sm:text-base cursor-pointer ${
              viewTab === 'steps'
                ? 'bg-[#29b1f5] border-sky-600 text-slate-950'
                : 'bg-white border-sky-200 text-slate-700'
            }`}
          >
            1. Langkah Kerja ({doneCount}/{steps.length})
          </button>
          <button
            type="button"
            onClick={() => {
              playTapSound();
              setViewTab('observe');
            }}
            className={`min-h-[44px] px-3 rounded-2xl border-2 font-extrabold text-sm sm:text-base cursor-pointer ${
              viewTab === 'observe'
                ? 'bg-[#ffc83d] border-amber-600 text-slate-950'
                : 'bg-white border-sky-200 text-slate-700'
            }`}
          >
            2. Catat Hasil {selectedObs ? '✓' : ''}
          </button>
        </div>

        {viewTab === 'steps' ? (
          <div className="flex-1 min-h-0 flex flex-col justify-center gap-1.5">
            {steps.map((step, idx) => {
              const checked = checkedSteps[idx];
              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => toggleStep(idx)}
                  className={`w-full min-h-[46px] px-3 py-1.5 rounded-2xl border-2 text-left flex items-center gap-2.5 font-bold text-[clamp(14px,2.4vw,18px)] transition-colors cursor-pointer ${
                    checked
                      ? 'bg-emerald-100 border-emerald-500 text-emerald-950'
                      : 'bg-white border-sky-200 text-slate-900 hover:bg-sky-50'
                  }`}
                >
                  {checked ? (
                    <CheckSquare className="w-6 h-6 text-emerald-700 shrink-0" aria-hidden="true" />
                  ) : (
                    <Square className="w-6 h-6 text-slate-400 shrink-0" aria-hidden="true" />
                  )}
                  <span className="leading-snug">{step}</span>
                </button>
              );
            })}
          </div>
        ) : (
          <div className="flex-1 min-h-0 flex flex-col justify-center gap-2">
            <div className="flex items-center gap-2 font-extrabold text-[clamp(16px,2.8vw,22px)] text-slate-950">
              <ClipboardCheck className="w-6 h-6 text-[#0284c7] shrink-0" aria-hidden="true" />
              <span>{observationPrompt}</span>
            </div>
            <div className="flex flex-col gap-2">
              {observationOptions.map((opt) => {
                const chosen = selectedObs === opt;
                return (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => {
                      playCorrectSound();
                      setSelectedObs(opt);
                      onSaveObservation(opt);
                    }}
                    className={`w-full min-h-[48px] px-3 py-2 rounded-2xl border-2 text-left font-bold text-[clamp(14px,2.4vw,18px)] cursor-pointer ${
                      chosen
                        ? 'bg-emerald-100 border-emerald-500 text-emerald-950'
                        : 'bg-white border-sky-200 text-slate-900 hover:bg-sky-50'
                    }`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
