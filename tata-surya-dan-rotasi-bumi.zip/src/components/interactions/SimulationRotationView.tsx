import React, { useEffect, useState } from 'react';
import { Play, Pause, Sun, Moon } from 'lucide-react';
import { AssetImage } from '../AssetImage';
import { playTapSound } from '../../utils/audio';

interface SimulationRotationViewProps {
  title: string;
  text: string;
  reduceMotion?: boolean;
  onInteract?: () => void;
}

export const SimulationRotationView: React.FC<SimulationRotationViewProps> = ({
  title,
  text,
  reduceMotion = false,
  onInteract,
}) => {
  // 0 deg = Kota Kita facing LEFT toward the Sun (Siang 12:00)
  // 90 deg = Sore 18:00
  // 180 deg = Malam 24:00 (facing right, away from Sun)
  // 270 deg = Pagi 06:00
  const [angle, setAngle] = useState<number>(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(false);

  useEffect(() => {
    if (!isAutoPlaying) return;
    const step = reduceMotion ? 15 : 2;
    const intervalMs = reduceMotion ? 250 : 40;
    const id = window.setInterval(() => {
      setAngle((prev) => (prev + step) % 360);
    }, intervalMs);
    return () => window.clearInterval(id);
  }, [isAutoPlaying, reduceMotion]);

  const handleAngleChange = (next: number) => {
    setIsAutoPlaying(false);
    setAngle(next);
    onInteract?.();
  };

  // Compute time state relative to Sun on the left
  const normalized = ((angle % 360) + 360) % 360;
  // At 0 deg -> 12:00, 90 -> 18:00, 180 -> 00:00, 270 -> 06:00
  const approxHour = Math.round(((normalized / 360) * 24 + 12) % 24);
  const hourLabel = `${String(approxHour).padStart(2, '0')}:00`;

  let phaseTitle = 'SIANG HARI';
  let phaseDesc = 'Kota Kita menghadap sinar Matahari.';
  let isDay = true;

  if (normalized >= 315 || normalized < 45) {
    phaseTitle = 'SIANG HARI';
    phaseDesc = 'Kota Kita menghadap langsung ke Matahari.';
    isDay = true;
  } else if (normalized >= 45 && normalized < 135) {
    phaseTitle = 'SORE HARI';
    phaseDesc = 'Kota Kita mulai berputar menjauhi sinar.';
    isDay = true;
  } else if (normalized >= 135 && normalized < 225) {
    phaseTitle = 'MALAM HARI';
    phaseDesc = 'Kota Kita membelakangi Matahari sehingga gelap.';
    isDay = false;
  } else {
    phaseTitle = 'PAGI HARI';
    phaseDesc = 'Kota Kita mulai berputar menghadap sinar lagi.';
    isDay = true;
  }

  // Marker position around Earth circle (0 deg = left side facing sun)
  const rad = ((normalized + 180) * Math.PI) / 180;
  const markerX = 50 + 40 * Math.cos(rad);
  const markerY = 50 + 40 * Math.sin(rad);

  return (
    <div className="w-full h-full flex flex-col md:grid md:grid-cols-12 gap-3 min-h-0 overflow-hidden">
      {/* Left/Top Stage: Sun + Sunlight + Rotating Earth */}
      <div className="md:col-span-7 flex-1 min-h-0 rounded-3xl bg-slate-900 border-4 border-sky-300 p-3 flex items-center justify-between gap-2 relative overflow-hidden">
        {/* Sunlight glow beam from left to Earth */}
        <div
          aria-hidden="true"
          className="absolute inset-y-0 left-0 w-3/4 pointer-events-none"
          style={{
            background:
              'linear-gradient(90deg, rgba(255,200,61,0.45) 0%, rgba(255,200,61,0.16) 55%, rgba(15,23,42,0) 100%)',
          }}
        />

        {/* Sun */}
        <div className="relative z-10 flex flex-col items-center shrink-0 w-20 sm:w-28 md:w-32">
          <AssetImage
            assetId="objek_matahari"
            labelBadge="Matahari"
            className="w-20 h-20 sm:w-28 sm:h-28 md:w-32 md:h-32"
          />
          <span className="mt-1 px-2 py-0.5 rounded-lg bg-amber-300 text-slate-950 font-extrabold text-xs sm:text-sm">
            Matahari
          </span>
        </div>

        {/* Light Rays Indicator */}
        <div className="relative z-10 hidden sm:flex flex-col items-center text-amber-200 font-bold text-xs md:text-sm shrink-0">
          <span>Sinar Matahari</span>
          <span aria-hidden="true" className="text-xl tracking-widest">
            &rarr; &rarr;
          </span>
        </div>

        {/* Rotating Earth Container */}
        <div className="relative z-10 flex flex-col items-center shrink-0">
          <div className="relative w-32 h-32 sm:w-40 sm:h-40 md:w-48 md:h-48 rounded-full overflow-hidden border-4 border-sky-200 bg-sky-950 flex items-center justify-center">
            <div
              className="w-full h-full flex items-center justify-center"
              style={{ transform: `rotate(${normalized}deg)` }}
            >
              <AssetImage
                assetId="objek_rotasi"
                labelBadge="Bumi"
                className="w-full h-full"
              />
            </div>

            {/* Right-half Night Shadow Overlay */}
            <div
              aria-hidden="true"
              className="absolute inset-y-0 right-0 w-1/2 bg-slate-950/65 pointer-events-none"
            />

            {/* "Kota Kita" Pin */}
            <div
              className="absolute w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-[#ffc83d] border-2 border-slate-950 shadow-md -translate-x-1/2 -translate-y-1/2 flex items-center justify-center"
              style={{ left: `${markerX}%`, top: `${markerY}%` }}
              title="Posisi Kota Kita"
            >
              <span className="w-2 h-2 rounded-full bg-rose-600" />
            </div>
          </div>

          <div className="mt-1 flex items-center gap-2 text-xs sm:text-sm font-extrabold">
            <span className="px-2 py-0.5 rounded-lg bg-amber-200 text-slate-950">
              Terang (Siang)
            </span>
            <span className="px-2 py-0.5 rounded-lg bg-slate-700 text-white">
              Gelap (Malam)
            </span>
          </div>
        </div>
      </div>

      {/* Right/Bottom Control Deck */}
      <div className="md:col-span-5 flex flex-col justify-center gap-2 shrink-0">
        <div>
          <h2 className="font-extrabold text-[clamp(20px,3.5vw,28px)] text-slate-950 leading-tight">
            {title}
          </h2>
          <p className="text-[clamp(14px,2.4vw,19px)] font-semibold text-slate-700 leading-snug">
            {text}
          </p>
        </div>

        {/* Live Status Banner (Icon + Text, dual coded) */}
        <div
          className={`rounded-2xl border-2 px-3 py-2 flex items-center gap-2.5 ${
            isDay
              ? 'bg-amber-100 border-amber-500 text-amber-950'
              : 'bg-indigo-950 border-indigo-400 text-white'
          }`}
        >
          {isDay ? (
            <Sun className="w-7 h-7 text-amber-600 shrink-0" aria-hidden="true" />
          ) : (
            <Moon className="w-7 h-7 text-amber-300 shrink-0" aria-hidden="true" />
          )}
          <div className="min-w-0">
            <div className="font-extrabold text-[clamp(16px,2.8vw,22px)] leading-tight tabular-nums">
              {phaseTitle} · {hourLabel}
            </div>
            <div className="text-xs sm:text-sm font-semibold leading-snug">
              {phaseDesc}
            </div>
          </div>
        </div>

        {/* Slider Control */}
        <div className="bg-white border-2 border-sky-200 rounded-2xl p-2.5">
          <div className="flex items-center justify-between text-sm sm:text-base font-extrabold text-slate-900 mb-1">
            <label htmlFor="rotation-slider">Putar Bumi</label>
            <span className="tabular-nums text-[#0284c7]">{normalized}°</span>
          </div>
          <input
            id="rotation-slider"
            type="range"
            min={0}
            max={359}
            value={normalized}
            onChange={(e) => handleAngleChange(Number(e.target.value))}
            className="w-full h-4 accent-[#29b1f5] cursor-pointer"
          />
        </div>

        {/* Preset Time Buttons + Auto Play */}
        <div className="grid grid-cols-5 gap-1.5">
          {[
            { label: 'Pagi', deg: 270 },
            { label: 'Siang', deg: 0 },
            { label: 'Sore', deg: 90 },
            { label: 'Malam', deg: 180 },
          ].map((preset) => (
            <button
              key={preset.label}
              type="button"
              onClick={() => {
                playTapSound();
                handleAngleChange(preset.deg);
              }}
              className="min-h-[44px] rounded-xl bg-sky-100 hover:bg-sky-200 border-2 border-sky-300 font-extrabold text-xs sm:text-sm text-sky-950 cursor-pointer"
            >
              {preset.label}
            </button>
          ))}
          <button
            type="button"
            onClick={() => {
              playTapSound();
              setIsAutoPlaying((p) => !p);
              onInteract?.();
            }}
            className={`min-h-[44px] rounded-xl border-2 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1 cursor-pointer ${
              isAutoPlaying
                ? 'bg-rose-100 border-rose-400 text-rose-950'
                : 'bg-[#5bcb7a] border-emerald-600 text-slate-950'
            }`}
            aria-label={isAutoPlaying ? 'Hentikan putaran otomatis' : 'Putar otomatis'}
          >
            {isAutoPlaying ? (
              <Pause className="w-4 h-4" aria-hidden="true" />
            ) : (
              <Play className="w-4 h-4" aria-hidden="true" />
            )}
            <span className="hidden sm:inline">{isAutoPlaying ? 'Jeda' : 'Putar'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
