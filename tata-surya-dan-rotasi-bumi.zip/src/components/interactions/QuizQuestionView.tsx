import React, { useEffect, useState } from 'react';
import { Lightbulb, CheckCircle2, HelpCircle } from 'lucide-react';
import { QuizQuestion } from '../../types/app';
import { AssetImage } from '../AssetImage';
import { playCorrectSound, playTapSound, playTryAgainSound } from '../../utils/audio';

interface QuizQuestionViewProps {
  questionData: QuizQuestion;
  onAnsweredCorrectly: (firstTry: boolean, attempts: number, selectedReason?: string) => void;
  onSpeakText?: (text: string) => void;
}

export const QuizQuestionView: React.FC<QuizQuestionViewProps> = ({
  questionData,
  onAnsweredCorrectly,
  onSpeakText,
}) => {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [attempts, setAttempts] = useState<number>(0);
  const [isCorrect, setIsCorrect] = useState<boolean>(false);
  const [hintLevel, setHintLevel] = useState<number>(0);
  const [feedback, setFeedback] = useState<string>('');
  const [stepMode, setStepMode] = useState<'answer' | 'reason'>('answer');
  const [selectedReasonId, setSelectedReasonId] = useState<string | null>(null);
  const [reasonFeedback, setReasonFeedback] = useState<string>('');

  // Reset when question changes
  useEffect(() => {
    setSelectedId(null);
    setAttempts(0);
    setIsCorrect(false);
    setHintLevel(0);
    setFeedback('');
    setStepMode('answer');
    setSelectedReasonId(null);
    setReasonFeedback('');
  }, [questionData.id]);

  const hasReasonStep = Boolean(
    questionData.reasonPrompt &&
      questionData.reasonOptions &&
      questionData.reasonOptions.length > 0
  );

  const handleSelectOption = (optionId: string) => {
    if (isCorrect) return;
    const nextAttempts = attempts + 1;
    setAttempts(nextAttempts);
    setSelectedId(optionId);

    if (optionId === questionData.correctOptionId) {
      playCorrectSound();
      setIsCorrect(true);
      setFeedback(questionData.correctFeedback);
      onSpeakText?.(questionData.correctFeedback);
      if (!hasReasonStep) {
        onAnsweredCorrectly(nextAttempts === 1, nextAttempts);
      }
    } else {
      playTryAgainSound();
      setFeedback(questionData.wrongFeedback);
      onSpeakText?.(questionData.wrongFeedback);
    }
  };

  const handleSelectReason = (reasonId: string) => {
    playTapSound();
    setSelectedReasonId(reasonId);
    const chosenLabel =
      questionData.reasonOptions?.find((r) => r.id === reasonId)?.label || '';
    if (reasonId === questionData.correctReasonId) {
      playCorrectSound();
      const msg = questionData.reasonFeedback || 'Alasanmu tepat sekali!';
      setReasonFeedback(msg);
      onSpeakText?.(msg);
      onAnsweredCorrectly(attempts === 1, attempts, chosenLabel);
    } else {
      playTryAgainSound();
      const nudge = 'Coba periksa lagi alasan yang paling sesuai dengan bukti.';
      setReasonFeedback(nudge);
      onSpeakText?.(nudge);
    }
  };

  const handleNextHint = () => {
    playTapSound();
    const nextLevel = Math.min(3, hintLevel + 1);
    setHintLevel(nextLevel);
    const hintText = questionData.hints[nextLevel - 1];
    if (hintText) {
      onSpeakText?.(`Petunjuk ${nextLevel}: ${hintText}`);
    }
  };

  if (stepMode === 'reason' && hasReasonStep) {
    const reasonCorrect = selectedReasonId === questionData.correctReasonId;
    return (
      <div className="w-full h-full flex flex-col justify-center gap-3 min-h-0 overflow-hidden max-w-3xl mx-auto">
        <div className="text-center">
          <span className="text-sm sm:text-base font-extrabold text-[#0284c7]">
            Langkah Berpikir · {questionData.title}
          </span>
          <h2 className="mt-1 font-extrabold text-[clamp(22px,4.2vw,34px)] text-slate-950 leading-tight">
            {questionData.reasonPrompt}
          </h2>
        </div>

        <div className="flex flex-col gap-2">
          {questionData.reasonOptions?.map((opt) => {
            const isChosen = selectedReasonId === opt.id;
            const isRight = opt.id === questionData.correctReasonId;
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => handleSelectReason(opt.id)}
                className={`w-full min-h-[56px] px-4 py-2 rounded-2xl border-2 font-bold text-[clamp(17px,3.2vw,24px)] text-left flex items-center justify-between gap-2 cursor-pointer transition-transform active:scale-[0.99] ${
                  isChosen && isRight
                    ? 'bg-emerald-100 border-emerald-500 text-emerald-950'
                    : isChosen && !isRight
                      ? 'bg-amber-100 border-amber-500 text-amber-950'
                      : 'bg-white border-sky-200 hover:bg-sky-50 text-slate-950'
                }`}
              >
                <span>{opt.label}</span>
                {isChosen && isRight && (
                  <CheckCircle2 className="w-6 h-6 text-emerald-700 shrink-0" aria-hidden="true" />
                )}
              </button>
            );
          })}
        </div>

        {reasonFeedback && (
          <div
            className={`rounded-2xl border-2 px-4 py-2.5 font-extrabold text-[clamp(16px,2.8vw,22px)] text-center ${
              reasonCorrect
                ? 'bg-emerald-100 border-emerald-500 text-emerald-950'
                : 'bg-amber-100 border-amber-500 text-amber-950'
            }`}
          >
            {reasonFeedback}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="w-full h-full flex flex-col md:grid md:grid-cols-12 gap-2.5 sm:gap-4 min-h-0 overflow-hidden items-center">
      {/* Left/Top: Illustration + Hint Control */}
      <div className="md:col-span-5 w-full flex flex-row md:flex-col items-center justify-center gap-3 min-h-0">
        <div className="w-20 h-20 sm:w-32 sm:h-32 md:w-48 md:h-48 shrink-0 flex items-center justify-center">
          <AssetImage
            assetId={questionData.assetId}
            animation="float"
            className="w-full h-full"
          />
        </div>

        <div className="flex flex-col items-start md:items-center gap-1.5 min-w-0">
          <span className="text-sm sm:text-base font-extrabold text-[#0284c7]">
            {questionData.title}
          </span>
          <button
            type="button"
            onClick={handleNextHint}
            className="min-h-[44px] px-3 py-1.5 rounded-2xl bg-[#ffc83d] hover:bg-amber-400 border-2 border-amber-500 text-slate-950 font-extrabold text-sm sm:text-base flex items-center gap-1.5 cursor-pointer"
          >
            <Lightbulb className="w-5 h-5 shrink-0" aria-hidden="true" />
            <span>
              {hintLevel === 0
                ? 'Minta Petunjuk'
                : hintLevel < 3
                  ? `Petunjuk Lagi (${hintLevel}/3)`
                  : 'Petunjuk (3/3)'}
            </span>
          </button>

          {hintLevel > 0 && (
            <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl px-3 py-1.5 text-sm sm:text-base font-bold text-amber-950 text-left md:text-center leading-snug">
              Petunjuk {hintLevel}: {questionData.hints[hintLevel - 1]}
            </div>
          )}
        </div>
      </div>

      {/* Right/Bottom: Question + 4 Options + Positive Feedback */}
      <div className="md:col-span-7 w-full flex-1 min-h-0 flex flex-col justify-center gap-2">
        <h2 className="font-extrabold text-[clamp(20px,3.8vw,30px)] text-slate-950 leading-tight text-center md:text-left">
          {questionData.question}
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {questionData.options.map((opt) => {
            const isChosen = selectedId === opt.id;
            const isRight = opt.id === questionData.correctOptionId;
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => handleSelectOption(opt.id)}
                disabled={isCorrect}
                className={`min-h-[54px] px-3 py-2 rounded-2xl border-2 font-bold text-[clamp(16px,2.8vw,22px)] leading-snug text-left flex items-center justify-between gap-2 transition-transform active:scale-95 cursor-pointer ${
                  isCorrect && isRight
                    ? 'bg-emerald-100 border-emerald-500 text-emerald-950'
                    : isChosen && !isRight
                      ? 'bg-amber-100 border-amber-500 text-amber-950'
                      : 'bg-white border-sky-200 hover:bg-sky-50 text-slate-950'
                }`}
              >
                <span>{opt.label}</span>
                {isCorrect && isRight && (
                  <CheckCircle2 className="w-6 h-6 text-emerald-700 shrink-0" aria-hidden="true" />
                )}
              </button>
            );
          })}
        </div>

        {feedback && (
          <div
            className={`rounded-2xl border-2 px-3 py-2 font-extrabold text-[clamp(15px,2.6vw,20px)] flex flex-col sm:flex-row items-center justify-between gap-2 ${
              isCorrect
                ? 'bg-emerald-100 border-emerald-500 text-emerald-950'
                : 'bg-amber-100 border-amber-500 text-amber-950'
            }`}
          >
            <span>{feedback}</span>
            {isCorrect && hasReasonStep && (
              <button
                type="button"
                onClick={() => {
                  playTapSound();
                  setStepMode('reason');
                  onSpeakText?.(questionData.reasonPrompt || '');
                }}
                className="min-h-[44px] px-4 py-1.5 rounded-xl bg-[#29b1f5] border-2 border-sky-600 text-slate-950 font-extrabold text-base flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <HelpCircle className="w-5 h-5" aria-hidden="true" />
                <span>Jelaskan Alasan</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
