import React, { useMemo, useState } from 'react';
import { RotateCcw, CheckCircle2 } from 'lucide-react';
import { PLANETS_ONLY } from '../../data/solarSystem';
import { playCorrectSound, playTapSound, playTryAgainSound } from '../../utils/audio';

interface PlanetOrderViewProps {
  title: string;
  text: string;
  onComplete?: () => void;
}

// Deterministic friendly shuffled order for Grade 6 learners
const INITIAL_SHUFFLED_IDS = [
  'mars',
  'merkurius',
  'jupiter',
  'venus',
  'neptunus',
  'bumi',
  'uranus',
  'saturnus',
];

export const PlanetOrderView: React.FC<PlanetOrderViewProps> = ({
  title,
  text,
  onComplete,
}) => {
  const [placedIds, setPlacedIds] = useState<string[]>([]);
  const [feedback, setFeedback] = useState<string>('Ketuk planet nomor 1 (terdekat Matahari).');
  const [isWrong, setIsWrong] = useState(false);

  const planetById = useMemo(() => {
    const map: Record<string, (typeof PLANETS_ONLY)[number]> = {};
    PLANETS_ONLY.forEach((p) => {
      map[p.id] = p;
    });
    return map;
  }, []);

  const nextExpectedPlanet = PLANETS_ONLY[placedIds.length];
  const isDone = placedIds.length === PLANETS_ONLY.length;

  const handleSelectPlanet = (planetId: string) => {
    if (isDone || placedIds.includes(planetId)) return;

    if (nextExpectedPlanet && planetId === nextExpectedPlanet.id) {
      const next = [...placedIds, planetId];
      setPlacedIds(next);
      setIsWrong(false);
      if (next.length === PLANETS_ONLY.length) {
        playCorrectSound();
        setFeedback('Hebat! Semua delapan planet sudah urut dari Matahari.');
        onComplete?.();
      } else {
        playTapSound();
        setFeedback(`Benar! Sekarang pilih planet ke-${next.length + 1}.`);
      }
    } else {
      playTryAgainSound();
      setIsWrong(true);
      const chosenName = planetById[planetId]?.name || '';
      setFeedback(`Belum pas, ${chosenName} bukan urutan ke-${placedIds.length + 1}. Coba lagi!`);
    }
  };

  const handleReset = () => {
    playTapSound();
    setPlacedIds([]);
    setIsWrong(false);
    setFeedback('Ketuk planet nomor 1 (terdekat Matahari).');
  };

  return (
    <div className="w-full h-full flex flex-col justify-between gap-2 min-h-0 overflow-hidden">
      <div className="flex items-start justify-between gap-2 shrink-0">
        <div>
          <h2 className="font-extrabold text-[clamp(20px,3.8vw,30px)] text-slate-950 leading-tight">
            {title}
          </h2>
          <p className="text-[clamp(15px,2.6vw,20px)] font-semibold text-slate-700 leading-snug">
            {text}
          </p>
        </div>
        <button
          type="button"
          onClick={handleReset}
          className="min-h-[44px] px-3 rounded-2xl bg-sky-100 hover:bg-sky-200 border-2 border-sky-300 text-sky-950 font-bold text-sm sm:text-base flex items-center gap-1.5 shrink-0 cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" aria-hidden="true" />
          <span>Ulangi</span>
        </button>
      </div>

      {/* 8 Ordered Slots */}
      <div className="grid grid-cols-4 gap-1.5 sm:gap-2 shrink-0">
        {PLANETS_ONLY.map((p, idx) => {
          const filledId = placedIds[idx];
          const filled = filledId ? planetById[filledId] : null;
          const isCurrent = idx === placedIds.length;
          return (
            <div
              key={p.id}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const droppedId = e.dataTransfer.getData('text/plain');
                if (isCurrent && droppedId) {
                  handleSelectPlanet(droppedId);
                }
              }}
              className={`min-h-[46px] sm:min-h-[54px] rounded-2xl border-2 px-1.5 py-1 flex flex-col items-center justify-center text-center ${
                filled
                  ? 'bg-emerald-100 border-emerald-500 text-emerald-950'
                  : isCurrent
                    ? 'bg-amber-50 border-amber-500 border-dashed text-amber-950'
                    : 'bg-white/70 border-slate-300 border-dashed text-slate-500'
              }`}
            >
              <span className="text-xs font-extrabold leading-none">Ke-{idx + 1}</span>
              <span className="text-[clamp(13px,2.4vw,18px)] font-extrabold truncate max-w-full mt-0.5">
                {filled ? filled.name : '?'}
              </span>
            </div>
          );
        })}
      </div>

      {/* Feedback Banner */}
      <div
        className={`rounded-2xl border-2 px-3 py-2 font-bold text-[clamp(15px,2.7vw,20px)] flex items-center gap-2 shrink-0 ${
          isDone
            ? 'bg-emerald-100 border-emerald-500 text-emerald-950'
            : isWrong
              ? 'bg-amber-100 border-amber-500 text-amber-950'
              : 'bg-sky-100 border-sky-300 text-sky-950'
        }`}
      >
        {isDone && <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" aria-hidden="true" />}
        <span>{feedback}</span>
      </div>

      {/* Planet Bank (Tap or Drag) */}
      <div className="grid grid-cols-4 gap-1.5 sm:gap-2 shrink-0">
        {INITIAL_SHUFFLED_IDS.map((pid) => {
          const planet = planetById[pid];
          const used = placedIds.includes(pid);
          return (
            <button
              key={pid}
              type="button"
              draggable={!used}
              onDragStart={(e) => {
                e.dataTransfer.setData('text/plain', pid);
              }}
              onClick={() => handleSelectPlanet(pid)}
              disabled={used}
              className={`min-h-[48px] sm:min-h-[54px] px-2 rounded-2xl border-2 font-extrabold text-[clamp(14px,2.5vw,19px)] transition-transform active:scale-95 cursor-pointer truncate ${
                used
                  ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-default active:scale-100'
                  : 'bg-[#ffc83d] hover:bg-amber-400 border-amber-500 text-slate-950 shadow-sm'
              }`}
            >
              {planet.name}
            </button>
          );
        })}
      </div>
    </div>
  );
};
