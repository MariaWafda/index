import React, { useEffect, useState } from 'react';
import { Play, Pause } from 'lucide-react';
import { AssetImage } from '../AssetImage';
import { playTapSound } from '../../utils/audio';

interface SimulationRevolutionViewProps {
  title: string;
  text: string;
  reduceMotion?: boolean;
  onInteract?: () => void;
}

const MONTHS = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];

function getSeasonDescription(monthIdx: number): {
  title: string;
  north: string;
  south: string;
  indonesia: string;
} {
  if (monthIdx === 11 || monthIdx === 0 || monthIdx === 1) {
    return {
      title: 'Posisi Awal / Akhir Tahun',
      north: 'Belahan Utara: Musim Dingin',
      south: 'Belahan Selatan: Musim Panas',
      indonesia: 'Indonesia: Musim Penghujan',
    };
  }
  if (monthIdx >= 2 && monthIdx <= 4) {
    return {
      title: 'Posisi Peralihan Pertama',
      north: 'Belahan Utara: Musim Semi',
      south: 'Belahan Selatan: Musim Gugur',
      indonesia: 'Indonesia: Peralihan ke Kemarau',
    };
  }
  if (monthIdx >= 5 && monthIdx <= 7) {
    return {
      title: 'Posisi Tengah Tahun',
      north: 'Belahan Utara: Musim Panas',
      south: 'Belahan Selatan: Musim Dingin',
      indonesia: 'Indonesia: Musim Kemarau',
    };
  }
  return {
    title: 'Posisi Peralihan Kedua',
    north: 'Belahan Utara: Musim Gugur',
    south: 'Belahan Selatan: Musim Semi',
    indonesia: 'Indonesia: Peralihan ke Hujan',
  };
}

export const SimulationRevolutionView: React.FC<SimulationRevolutionViewProps> = ({
  title,
  text,
  reduceMotion = false,
  onInteract,
}) => {
  const [monthIdx, setMonthIdx] = useState<number>(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(false);

  useEffect(() => {
    if (!isAutoPlaying) return;
    const id = window.setInterval(
      () => {
        setMonthIdx((prev) => (prev + 1) % 12);
      },
      reduceMotion ? 1100 : 750
    );
    return () => window.clearInterval(id);
  }, [isAutoPlaying, reduceMotion]);

  const angleRad = ((monthIdx / 12) * 360 - 90) * (Math.PI / 180);
  // Orbit radius in percent inside square stage (radius ~ 36%)
  const earthX = 50 + 36 * Math.cos(angleRad);
  const earthY = 50 + 36 * Math.sin(angleRad);

  const info = getSeasonDescription(monthIdx);

  return (
    <div className="w-full h-full flex flex-col md:grid md:grid-cols-12 gap-3 min-h-0 overflow-hidden">
      {/* Orbit Stage */}
      <div className="md:col-span-6 flex-1 min-h-0 rounded-3xl bg-slate-900 border-4 border-sky-300 p-2 flex items-center justify-center relative overflow-hidden">
        <div className="relative w-52 h-52 sm:w-64 sm:h-64 md:w-72 md:h-72 aspect-square">
          {/* Dashed Orbit Ring */}
          <div
            aria-hidden="true"
            className="absolute inset-[14%] rounded-full border-4 border-dashed border-sky-400/60"
          />

          {/* Sun at Center */}
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center">
            <AssetImage
              assetId="objek_matahari"
              labelBadge="Matahari"
              className="w-full h-full"
            />
          </div>

          {/* Earth Moving Along Orbit */}
          <div
            className="absolute w-14 h-14 sm:w-16 sm:h-16 -translate-x-1/2 -translate-y-1/2 transition-all duration-300"
            style={{ left: `${earthX}%`, top: `${earthY}%` }}
          >
            <div className="w-full h-full rounded-full border-2 border-amber-300 bg-sky-950 p-0.5 flex items-center justify-center">
              <AssetImage
                assetId="objek_revolusi"
                labelBadge="Bumi"
                className="w-full h-full"
              />
            </div>
          </div>

          {/* Month Label Corner */}
          <div className="absolute top-0 left-0 px-2.5 py-1 rounded-xl bg-amber-300 text-slate-950 font-extrabold text-xs sm:text-sm">
            {MONTHS[monthIdx]}
          </div>
          <div className="absolute bottom-0 right-0 px-2 py-0.5 rounded-xl bg-slate-800 text-sky-200 font-bold text-xs">
            Orbit 1 Tahun
          </div>
        </div>
      </div>

      {/* Controls & Info */}
      <div className="md:col-span-6 flex flex-col justify-center gap-2 shrink-0">
        <div>
          <h2 className="font-extrabold text-[clamp(20px,3.5vw,28px)] text-slate-950 leading-tight">
            {title}
          </h2>
          <p className="text-[clamp(14px,2.4vw,19px)] font-semibold text-slate-700 leading-snug">
            {text}
          </p>
        </div>

        <div className="bg-amber-50 border-2 border-amber-400 rounded-2xl p-2.5 text-slate-950">
          <div className="font-extrabold text-[clamp(16px,2.8vw,22px)] text-amber-950">
            Bulan {MONTHS[monthIdx]} · {info.title}
          </div>
          <div className="mt-1 space-y-0.5 text-xs sm:text-sm md:text-base font-bold text-slate-800">
            <div>{info.north}</div>
            <div>{info.south}</div>
            <div className="text-[#0284c7]">{info.indonesia}</div>
          </div>
        </div>

        <div className="bg-white border-2 border-sky-200 rounded-2xl p-2.5">
          <div className="flex items-center justify-between text-sm sm:text-base font-extrabold text-slate-900 mb-1">
            <label htmlFor="rev-slider">Geser Bulan</label>
            <span className="tabular-nums text-[#0284c7]">
              Bulan {monthIdx + 1} / 12
            </span>
          </div>
          <input
            id="rev-slider"
            type="range"
            min={0}
            max={11}
            value={monthIdx}
            onChange={(e) => {
              setIsAutoPlaying(false);
              setMonthIdx(Number(e.target.value));
              onInteract?.();
            }}
            className="w-full h-4 accent-[#29b1f5] cursor-pointer"
          />
        </div>

        <div className="grid grid-cols-5 gap-1.5">
          {[
            { label: 'Jan', idx: 0 },
            { label: 'Apr', idx: 3 },
            { label: 'Jul', idx: 6 },
            { label: 'Okt', idx: 9 },
          ].map((preset) => (
            <button
              key={preset.label}
              type="button"
              onClick={() => {
                playTapSound();
                setIsAutoPlaying(false);
                setMonthIdx(preset.idx);
                onInteract?.();
              }}
              className={`min-h-[44px] rounded-xl border-2 font-extrabold text-xs sm:text-sm cursor-pointer ${
                monthIdx === preset.idx
                  ? 'bg-[#ffc83d] border-amber-600 text-slate-950'
                  : 'bg-sky-100 border-sky-300 text-sky-950'
              }`}
            >
              {preset.label}
            </button>
          ))}
          <button
            type="button"
            onClick={() => {
              playTapSound();
              setIsAutoPlaying((p) => !p);
              onInteract?.();
            }}
            className={`min-h-[44px] rounded-xl border-2 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1 cursor-pointer ${
              isAutoPlaying
                ? 'bg-rose-100 border-rose-400 text-rose-950'
                : 'bg-[#5bcb7a] border-emerald-600 text-slate-950'
            }`}
          >
            {isAutoPlaying ? (
              <Pause className="w-4 h-4" aria-hidden="true" />
            ) : (
              <Play className="w-4 h-4" aria-hidden="true" />
            )}
            <span className="hidden sm:inline">{isAutoPlaying ? 'Jeda' : 'Putar'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
