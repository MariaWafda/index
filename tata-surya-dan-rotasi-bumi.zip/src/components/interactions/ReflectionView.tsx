import React, { useState } from 'react';
import { Smile, ThumbsUp, HelpCircle, CheckCircle2 } from 'lucide-react';
import { AssetId } from '../../types/app';
import { AssetImage } from '../AssetImage';
import { playCorrectSound, playTapSound } from '../../utils/audio';

interface ReflectionViewProps {
  meetingNumber: 1 | 2 | 3 | 4;
  title: string;
  text: string;
  assetId: AssetId;
  learnedOptions: string[];
  initialMood?: 'senang' | 'paham' | 'bingung';
  initialLearned?: string;
  onSaveReflection: (mood: 'senang' | 'paham' | 'bingung', learned: string) => void;
}

export const ReflectionView: React.FC<ReflectionViewProps> = ({
  meetingNumber,
  title,
  text,
  assetId,
  learnedOptions,
  initialMood,
  initialLearned,
  onSaveReflection,
}) => {
  const [mood, setMood] = useState<'senang' | 'paham' | 'bingung' | null>(
    initialMood || null
  );
  const [learned, setLearned] = useState<string>(initialLearned || '');

  const handleChooseMood = (m: 'senang' | 'paham' | 'bingung') => {
    playTapSound();
    setMood(m);
    if (learned) {
      onSaveReflection(m, learned);
    }
  };

  const handleChooseLearned = (item: string) => {
    playCorrectSound();
    setLearned(item);
    onSaveReflection(mood || 'senang', item);
  };

  return (
    <div className="w-full h-full flex flex-col md:grid md:grid-cols-12 gap-3 min-h-0 overflow-hidden items-center">
      <div className="md:col-span-4 flex flex-row md:flex-col items-center justify-center gap-3 shrink-0">
        <div className="w-16 h-16 sm:w-28 sm:h-28 md:w-40 md:h-40 shrink-0 flex items-center justify-center">
          <AssetImage
            assetId={assetId}
            animation="bounce"
            className="w-full h-full"
          />
        </div>
        <div className="text-left md:text-center">
          <div className="text-sm font-extrabold text-[#0284c7]">
            Penutup Pertemuan {meetingNumber}
          </div>
          <h2 className="font-extrabold text-[clamp(20px,3.8vw,30px)] text-slate-950 leading-tight">
            {title}
          </h2>
          <p className="text-[clamp(14px,2.4vw,19px)] font-semibold text-slate-700 leading-snug">
            {text}
          </p>
        </div>
      </div>

      <div className="md:col-span-8 w-full flex-1 min-h-0 flex flex-col justify-center gap-2.5">
        <div>
          <div className="font-extrabold text-[clamp(15px,2.6vw,20px)] text-slate-900 mb-1.5">
            1. Bagaimana perasaanmu hari ini?
          </div>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'senang' as const, label: 'Senang', Icon: Smile },
              { id: 'paham' as const, label: 'Paham', Icon: ThumbsUp },
              { id: 'bingung' as const, label: 'Perlu Ulang', Icon: HelpCircle },
            ].map(({ id, label, Icon }) => {
              const active = mood === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => handleChooseMood(id)}
                  className={`min-h-[52px] px-2 py-2 rounded-2xl border-2 font-extrabold text-[clamp(14px,2.5vw,19px)] flex items-center justify-center gap-1.5 cursor-pointer transition-transform active:scale-95 ${
                    active
                      ? 'bg-[#ffc83d] border-amber-600 text-slate-950'
                      : 'bg-white border-sky-200 hover:bg-sky-50 text-slate-900'
                  }`}
                >
                  <Icon className="w-5 h-5 shrink-0" aria-hidden="true" />
                  <span>{label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <div className="font-extrabold text-[clamp(15px,2.6vw,20px)] text-slate-900 mb-1.5">
            2. Apa yang paling kamu ingat hari ini?
          </div>
          <div className="flex flex-col gap-1.5">
            {learnedOptions.map((item) => {
              const active = learned === item;
              return (
                <button
                  key={item}
                  type="button"
                  onClick={() => handleChooseLearned(item)}
                  className={`w-full min-h-[46px] px-3 py-1.5 rounded-2xl border-2 font-bold text-[clamp(14px,2.4vw,19px)] text-left flex items-center justify-between gap-2 cursor-pointer ${
                    active
                      ? 'bg-emerald-100 border-emerald-500 text-emerald-950'
                      : 'bg-white border-sky-200 hover:bg-sky-50 text-slate-900'
                  }`}
                >
                  <span>{item}</span>
                  {active && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" aria-hidden="true" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
