import React, { useState } from 'react';
import { CELESTIAL_BODIES } from '../../data/solarSystem';
import { AssetImage } from '../AssetImage';
import { playTapSound } from '../../utils/audio';

interface PlanetCompareViewProps {
  title: string;
  text: string;
}

const COMPARE_CHOICES = CELESTIAL_BODIES.filter((b) =>
  ['matahari', 'merkurius', 'bumi', 'mars', 'jupiter', 'saturnus'].includes(b.id)
);

export const PlanetCompareView: React.FC<PlanetCompareViewProps> = ({
  title,
  text,
}) => {
  const [leftId, setLeftId] = useState('bumi');
  const [rightId, setRightId] = useState('jupiter');

  const left = COMPARE_CHOICES.find((b) => b.id === leftId) || COMPARE_CHOICES[2];
  const right = COMPARE_CHOICES.find((b) => b.id === rightId) || COMPARE_CHOICES[4];

  const comparisonSentence =
    left.relativeSizePercent === right.relativeSizePercent
      ? `${left.name} dan ${right.name} ukurannya sama.`
      : left.relativeSizePercent > right.relativeSizePercent
        ? `${left.name} lebih besar daripada ${right.name}.`
        : `${right.name} lebih besar daripada ${left.name}.`;

  return (
    <div className="w-full h-full flex flex-col justify-between gap-2 min-h-0 overflow-hidden">
      <div className="shrink-0">
        <h2 className="font-extrabold text-[clamp(20px,3.8vw,30px)] text-slate-950 leading-tight">
          {title}
        </h2>
        <p className="text-[clamp(15px,2.5vw,20px)] font-semibold text-slate-700 leading-snug">
          {text}
        </p>
      </div>

      {/* Two Comparison Cards */}
      <div className="flex-1 min-h-0 grid grid-cols-2 gap-2.5 sm:gap-4">
        {/* Card A */}
        <div className="bg-white border-2 border-sky-300 rounded-3xl p-2 sm:p-3 flex flex-col justify-between min-h-0">
          <div className="flex flex-wrap gap-1 justify-center">
            {COMPARE_CHOICES.map((b) => (
              <button
                key={b.id}
                type="button"
                onClick={() => {
                  playTapSound();
                  setLeftId(b.id);
                }}
                className={`px-2 py-1 rounded-xl text-xs sm:text-sm font-extrabold border cursor-pointer ${
                  leftId === b.id
                    ? 'bg-[#29b1f5] border-sky-600 text-slate-950'
                    : 'bg-sky-50 border-sky-200 text-slate-800'
                }`}
              >
                {b.name}
              </button>
            ))}
          </div>

          <div className="flex-1 min-h-0 flex items-center justify-center py-1">
            <div
              className="flex items-center justify-center transition-transform"
              style={{
                width: `${Math.max(40, left.relativeSizePercent)}%`,
                height: `${Math.max(40, left.relativeSizePercent)}%`,
                maxWidth: '130px',
                maxHeight: '130px',
              }}
            >
              <AssetImage
                assetId={left.assetId}
                labelBadge={left.name}
                className="w-full h-full"
              />
            </div>
          </div>

          <div className="w-full">
            <div className="text-center font-extrabold text-[clamp(16px,2.8vw,22px)] text-slate-950">
              {left.name}
            </div>
            <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden mt-1">
              <div
                className="h-full bg-[#29b1f5] rounded-full transition-all"
                style={{ width: `${left.relativeSizePercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Card B */}
        <div className="bg-white border-2 border-amber-300 rounded-3xl p-2 sm:p-3 flex flex-col justify-between min-h-0">
          <div className="flex flex-wrap gap-1 justify-center">
            {COMPARE_CHOICES.map((b) => (
              <button
                key={b.id}
                type="button"
                onClick={() => {
                  playTapSound();
                  setRightId(b.id);
                }}
                className={`px-2 py-1 rounded-xl text-xs sm:text-sm font-extrabold border cursor-pointer ${
                  rightId === b.id
                    ? 'bg-[#ffc83d] border-amber-600 text-slate-950'
                    : 'bg-amber-50 border-amber-200 text-slate-800'
                }`}
              >
                {b.name}
              </button>
            ))}
          </div>

          <div className="flex-1 min-h-0 flex items-center justify-center py-1">
            <div
              className="flex items-center justify-center transition-transform"
              style={{
                width: `${Math.max(40, right.relativeSizePercent)}%`,
                height: `${Math.max(40, right.relativeSizePercent)}%`,
                maxWidth: '130px',
                maxHeight: '130px',
              }}
            >
              <AssetImage
                assetId={right.assetId}
                labelBadge={right.name}
                className="w-full h-full"
              />
            </div>
          </div>

          <div className="w-full">
            <div className="text-center font-extrabold text-[clamp(16px,2.8vw,22px)] text-slate-950">
              {right.name}
            </div>
            <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden mt-1">
              <div
                className="h-full bg-[#ffc83d] rounded-full transition-all"
                style={{ width: `${right.relativeSizePercent}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-emerald-100 border-2 border-emerald-400 rounded-2xl px-3 py-2 text-center font-extrabold text-[clamp(16px,2.8vw,22px)] text-emerald-950 shrink-0">
        {comparisonSentence}
      </div>
    </div>
  );
};
