import { AssetId } from '../types/app';

export interface CelestialBody {
  id: string;
  order: number;
  name: string;
  role: string;
  shortFact: string;
  sizeNote: string;
  relativeSizePercent: number; // proportional visual bar for simple comparison
  colorTone: string;
  assetId: AssetId;
}

export const CELESTIAL_BODIES: CelestialBody[] = [
  {
    id: 'matahari',
    order: 0,
    name: 'Matahari',
    role: 'Bintang Pusat Tata Surya',
    shortFact: 'Matahari adalah bintang yang memancarkan cahaya dan panas sendiri.',
    sizeNote: 'Paling besar di tata surya, jauh lebih besar dari semua planet.',
    relativeSizePercent: 100,
    colorTone: 'bg-amber-100 border-amber-400 text-amber-950',
    assetId: 'objek_matahari',
  },
  {
    id: 'merkurius',
    order: 1,
    name: 'Merkurius',
    role: 'Planet ke-1',
    shortFact: 'Planet paling dekat dengan Matahari dan berukuran paling kecil.',
    sizeNote: 'Lebih kecil dari Bumi.',
    relativeSizePercent: 12,
    colorTone: 'bg-slate-100 border-slate-400 text-slate-900',
    assetId: 'objek_planet',
  },
  {
    id: 'venus',
    order: 2,
    name: 'Venus',
    role: 'Planet ke-2',
    shortFact: 'Planet paling panas karena diselimuti awan tebal yang menahan panas.',
    sizeNote: 'Ukurannya hampir sama dengan Bumi.',
    relativeSizePercent: 26,
    colorTone: 'bg-orange-100 border-orange-400 text-orange-950',
    assetId: 'objek_planet',
  },
  {
    id: 'bumi',
    order: 3,
    name: 'Bumi',
    role: 'Planet ke-3',
    shortFact: 'Rumah kita yang memiliki air cair, udara, dan suhu yang nyaman.',
    sizeNote: 'Planet berbatu terbesar keempat dari Matahari.',
    relativeSizePercent: 28,
    colorTone: 'bg-sky-100 border-sky-400 text-sky-950',
    assetId: 'objek_siang_dan_malam',
  },
  {
    id: 'mars',
    order: 4,
    name: 'Mars',
    role: 'Planet ke-4',
    shortFact: 'Sering disebut planet merah karena tanahnya mengandung karat besi.',
    sizeNote: 'Sekitar setengah ukuran Bumi.',
    relativeSizePercent: 16,
    colorTone: 'bg-rose-100 border-rose-400 text-rose-950',
    assetId: 'objek_planet',
  },
  {
    id: 'jupiter',
    order: 5,
    name: 'Jupiter',
    role: 'Planet ke-5',
    shortFact: 'Planet paling besar di tata surya dan tersusun dari gas.',
    sizeNote: 'Lebarnya sekitar sebelas kali lebar Bumi.',
    relativeSizePercent: 86,
    colorTone: 'bg-yellow-100 border-yellow-500 text-yellow-950',
    assetId: 'objek_planet',
  },
  {
    id: 'saturnus',
    order: 6,
    name: 'Saturnus',
    role: 'Planet ke-6',
    shortFact: 'Terkenal memiliki cincin indah dari es dan debu.',
    sizeNote: 'Planet terbesar kedua setelah Jupiter.',
    relativeSizePercent: 74,
    colorTone: 'bg-amber-50 border-amber-400 text-amber-950',
    assetId: 'objek_planet',
  },
  {
    id: 'uranus',
    order: 7,
    name: 'Uranus',
    role: 'Planet ke-7',
    shortFact: 'Planet raksasa es berwarna biru kehijauan yang berputar miring.',
    sizeNote: 'Sekitar empat kali lebih lebar dari Bumi.',
    relativeSizePercent: 48,
    colorTone: 'bg-cyan-100 border-cyan-400 text-cyan-950',
    assetId: 'objek_planet',
  },
  {
    id: 'neptunus',
    order: 8,
    name: 'Neptunus',
    role: 'Planet ke-8',
    shortFact: 'Planet terjauh dari Matahari yang sangat dingin dan berangin kencang.',
    sizeNote: 'Hampir sebesar Uranus.',
    relativeSizePercent: 46,
    colorTone: 'bg-indigo-100 border-indigo-400 text-indigo-950',
    assetId: 'objek_planet',
  },
];

export const PLANETS_ONLY = CELESTIAL_BODIES.filter((b) => b.order >= 1);

export interface GlossaryItem {
  id: string;
  term: string;
  meaning: string;
  example: string;
  assetId: AssetId;
}

export const GLOSSARY_ITEMS: GlossaryItem[] = [
  {
    id: 'tata_surya',
    term: 'Tata Surya',
    meaning: 'Kumpulan Matahari dan semua benda langit yang mengelilinginya.',
    example: 'Ada delapan planet di tata surya kita.',
    assetId: 'objek_simulasi_rotasi_dan_revo',
  },
  {
    id: 'matahari',
    term: 'Matahari',
    meaning: 'Bintang besar di pusat tata surya yang memancarkan cahaya sendiri.',
    example: 'Cahaya Matahari membuat Bumi hangat dan terang.',
    assetId: 'objek_matahari',
  },
  {
    id: 'planet',
    term: 'Planet',
    meaning: 'Benda langit besar yang mengelilingi Matahari dan tidak bercahaya sendiri.',
    example: 'Bumi adalah planet tempat kita tinggal.',
    assetId: 'objek_planet',
  },
  {
    id: 'orbit',
    term: 'Orbit',
    meaning: 'Jalur lintasan planet saat bergerak mengelilingi Matahari.',
    example: 'Setiap planet tetap berada di orbitnya sendiri.',
    assetId: 'objek_revolusi',
  },
  {
    id: 'rotasi',
    term: 'Rotasi Bumi',
    meaning: 'Gerakan Bumi berputar pada porosnya dari barat ke timur.',
    example: 'Satu kali rotasi Bumi memakan waktu sekitar 24 jam.',
    assetId: 'objek_rotasi',
  },
  {
    id: 'siang_malam',
    term: 'Siang dan Malam',
    meaning: 'Sisi Bumi yang kena sinar Matahari menjadi siang, sisi sebaliknya malam.',
    example: 'Saat kita tidur malam, sisi lain Bumi sedang siang.',
    assetId: 'objek_siang_dan_malam',
  },
  {
    id: 'revolusi',
    term: 'Revolusi Bumi',
    meaning: 'Gerakan Bumi mengelilingi Matahari pada orbitnya.',
    example: 'Satu kali revolusi Bumi memakan waktu sekitar satu tahun.',
    assetId: 'objek_revolusi',
  },
];

export interface FunFactItem {
  id: string;
  title: string;
  fact: string;
  assetId: AssetId;
}

export const FUN_FACTS: FunFactItem[] = [
  {
    id: 'fakta_1',
    title: 'Bulan Memantulkan Cahaya',
    fact: 'Bulan tidak membuat cahaya sendiri. Bulan terlihat terang karena memantulkan cahaya Matahari.',
    assetId: 'objek_siang_dan_malam',
  },
  {
    id: 'fakta_2',
    title: 'Matahari Tidak Mengelilingi Bumi',
    fact: 'Matahari terlihat terbit dan terbenam karena Bumi yang berputar pada porosnya.',
    assetId: 'objek_rotasi',
  },
  {
    id: 'fakta_3',
    title: 'Ukuran dan Jarak Sebenarnya',
    fact: 'Di luar angkasa, jarak antar planet sangatlah jauh. Gambar peta dibuat rapat agar mudah dilihat.',
    assetId: 'objek_planet',
  },
  {
    id: 'fakta_4',
    title: 'Satu Hari di Bumi',
    fact: 'Bumi berputar penuh satu kali setiap sekitar 24 jam. Inilah yang membuat waktu satu hari.',
    assetId: 'objek_simulasi_rotasi_dan_revo',
  },
  {
    id: 'fakta_5',
    title: 'Perjalanan Satu Tahun',
    fact: 'Bumi membutuhkan sekitar 365 hari untuk satu kali mengelilingi Matahari.',
    assetId: 'objek_revolusi',
  },
];
